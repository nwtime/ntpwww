extern int plot_choice;

void plots_X(),   plots_ps();
void plot_X(),    plot_ps();
void frame_X(),   frame_ps();
void satellite_X(), satellite_ps();
void Text_X(), Text_ps();
void circle_X(), circle_ps();
void setFGcolor_X(), setcolor_ps();

void
plots (x0, y0, xmax, ymax)
double x0, y0, xmax, ymax;
{

	if (plot_choice == 0)
		plots_X(x0, y0, xmax, ymax);

	if (plot_choice == 2)
		plots_ps();
}

void
plot(x,y,ic)
double  x,y;
int	ic;
{
	if (plot_choice == 0)
		plot_X(x,y,ic);

	if (plot_choice == 2)
		plot_ps(x,y,ic);
}

void
frame()
{
	if (plot_choice == 0)
		frame_X();
	if (plot_choice == 2)
		frame_ps();
}


void
Text(double x, double y, char *s)
{
	if (plot_choice == 0)
		Text_X(x, y, s);
	if (plot_choice == 2)
		Text_ps(x, y, s);
}

void
satellite (int id, int az, int el, int posn)
{
	if (plot_choice == 0)
		satellite_X  (id, az, el, posn);
	if (plot_choice == 2)
		satellite_ps (id, az, el, posn);
}

void
circle(double x, double y, double R)
{
	if (plot_choice == 0)
		circle_X(x, y, R);
	if (plot_choice == 2)
		circle_ps(x, y, R);
}

void
set_color()
{
	if (plot_choice == 0)
		setFGcolor_X();
	if (plot_choice == 2)
		setcolor_ps();
}
