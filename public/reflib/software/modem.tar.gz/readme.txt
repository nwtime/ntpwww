************************************************************************
*                                                                      *
* Copyright (c) David L. Mills 1995                                    *
*                                                                      *
* Permission to use, copy, modify, and distribute this software and    *
* its documentation for any purpose and without fee is hereby granted, *
* provided that the above copyright notice appears in all copies and   *
* that both the copyright notice and this permission notice appear in  *
* supporting documentation, and that the name University of Delaware   *
* not be used in advertising or publicity pertaining to distribution   *
* of the software without specific, written prior permission. The      *
* University of Delaware makes no representations about the            *
* suitability this software for any purpose. It is provided "as is"    *
* without express or implied warranty.                                 *
*                                                                      *
************************************************************************

FSK modem/TNC for HF RTTY

This program implements a FSK modem/TNC for HF asynchronous Baudot (ITA-
2) and synchronous SITOR/AMTOR (CCIR 476 Mode B) signalling. It operates
at speeds to 100 baud, either as a TNC with ASCII input/output via the
onboard UART, or as a regenerator with clean AFSK output reconstructed
from a possibly noisy input. The algorithms use Butterworth and matched
filters, soft-decision detection, maximum a-priory (MAP) estimation and
Viterbi decoding. In case of continuous asynchronous signalling, the
modem can operate in a synchronous mode using a phase-lock loop (PLL) to
flywheel through momentary carrier fades. The predetection design and
many of the operator features were inspired by the Dovetron TU of long
ago, but implemented in DSP, rather than analog form. The postdetection
design, including MAP estimation, Viterbi and matched-filter decoding
and synchronous mode was inspired by a LSI-11 program also of long ago.
The algorithms implement a theoretically optimum receiver for FSK RTTY
and SITOR signals in additive white Gaussian noise with nonfading and
Rayleigh fading channels. If this thing can't pull RTTY and SITOR
signals from the muck, nothing can.

The modem  operates as both a TNC and a regenerator. When operating as a
TNC, the modem is connected to a HF transceiver operating in LSB mode,
so that the space tone is transmitted at the lower radio frequency. The
modem can also be connected to a VHF FM transceiver. In receive mode,
received Baudot characters decoded from RTTY and SITOR signals are
converted to ASCII and sent to the terminal program at the speed and
character format selected by the hardware and program, currently 19,200
baud. In transmit mode, ASCII characters received from the terminal
program are converted to Baudot and used to modulate the AFSK output.
Since the modem transmitter and receiver are functionally independent
and the program can operate with both radio ports, this feature might be
useful in a crossband repeater.

The transmit/receive protocol operates as in the PK-232 TNC. The x
command switches to transmit mode and keys the PTT line, following which
text is transmitted as received from the terminal program. The ASCII ACK
(ctrl-F) character switches to receive mode when the transmit buffer is
empty; the ASCII EOT (ctrl-D) character purges the buffer and switches
to receive mode immediately. The p{1-2} command selects the radio port
to use for the transmit, receive and tune functions. Separate first-in
first-out (FIFO) buffers are used to save transmitted and received text.
Flow control for the transmit buffer is implemented using hardware
clear-to-send (CTS) handshaking only.

The frequencies of the mark and space tones are designed to match the
AEA PK-232 TNC in either narrow shift (WIDE OFF) or wide shift (WIDE ON)
mode. In narrow shift modes, the input and output mark tone is 2125 Hz
and the input and output space tone is 2295 Hz. In wide shift modes, the
input mark and space tones vary to match the shift, with a center
frequency of 1700 Hz. In wide shift modes, the output mark tone is 1275
Hz and the output space tone is 2125 Hz. The o{0-2} command can be used
to switch between narrow and wide output shifts, if necessary. The baud
rate of the transmit signal is equal to that of the receive signal.

The character translation tables use the US versions of the ITA-2
(Baudot) alphabet and the ITA-5 (ASCII) alphabet. Operating speeds used
by both the receiver and transmitter are selectable from the set 100,
75, 50, 45.45, 25 and 10 baud. Speeds below 45.45 baud are useful in
marginal conditions where the FSK signal can barely be heard by ear on a
SSB voice receiver. The predetection matched filter at 45.45 baud
provides 6dB of processing gain over the typical 100-Hz postdetection
lowpass filter used in many TNCs. In addition, the 10-baud rate can
provide an additional 6dB gain.

The CCIR 476 SITOR Mode B (FEC) mode is compatible with the AMTOR Mode B
(FEC) used by the amateur community. This mode is used for HF broadcasts
such as the W1AW and NAVTEX bulletins. This modem supports both
receiving and transmitting in this mode at all baud rates and shifts
supported by the RTTY mode, but defaults to 100 baud and 170-Hz shift.
Only these defaults are permitted under current FCC regulations. Should
operation at lower baud rates be permitted by the FCC under a Special
Temporary Authorization (STA), for example, the modem performance in
this mode at 10 baud would be truly awesome. The same transmitter
control functions in RTTY mode are also active in SITOR mode.

Tuning Instructions

First, make sure LED 2 is on (dimly) to indicate the modem program is
running. Set the baud rate, mark/space shift and filter type using the
b{1-6} and m{1-8} commands listed below. For ordinary RTTY amateur
operation at 45.45 baud, 170-Hz shift, use the b4m8 commands and lower
sideband; for most RTTY commercial operation at 75 baud and 850-Hz
shift, use the b2m1 commands and upper sideband. When first loaded and
after the r (reset) command, the modem is set for RTTY operation at 75
baud and compromise 600-Hz shift, as in the b2m2 commands. The y command
switches to SITOR operation; the r command resets the modem and restores
the defaults.

Tune in a RTTY or SITOR signal and adjust the receiver output signal
level so that LED 1 turns on occasionally, but is not solidly lit. If a
speaker or headphones is connected to the speaker jack, use the d1
command to monitor the modem input signal. Adjust the receiver frequency
to maximize the intensity of LED 3 (carrier detect) or the midpoint of
the tuning range where LED 3 turns on from off. It may be useful to
temporarily reduce the receiver gain to the point that LED 3 just turns
on at the center of the range. Use the g{0-7} command to reduce the
analog gain of the DSP-93 or the l{0-5} command to reduce the limiter
gain, if necessary. The t{+-} command can be used to tune the receiver,
if the receiver and cable support the DSP-93 signals; however, note that
the tuning resolution of some radios is not fine enough when the
predetection matched filters are in use (m{5-8} command).

If the FSK signal is not being modulated, you may observe two peaks in
LED 3 intensity, one where LED 5 (mark) turns on, the other where LED 6
(space) turns on. The correct peak is where LED 5 turns on, which can
then be used as a fine-tune indicator. If the FSK signal is being
modulated, LED 5 and LED 6 should be flashing alternately. In this case,
the receiver frequency should be adjusted to equalize the intensity of
LED 5 and LED 6. Use the m{+-} command to fine-tune the space frequency
and maximize the intensity of LED 6. Usually, this is necessary only if
the transmitter is using a nonstandard shift. A word of caution,
however; this thing is really very selective, especially when the
predetection matched filter is in use, where it needs to be tuned to
within 10 Hz for optimum results.

LED 7 shows the space signal of the regenerated signal. It flashes to
indicate a valid character is being received. When transmitting in RTTY
operation, it flashes as each character is transmitted; in SITOR
operation, it flashes continuously. When the transmit buffer nears
capacity, the modem will drop the CTS line, which normally stops
transmission from the terminal program. In this condition, indicated
when LED 7 flashes regularly at a 2-Hz rate, it is not possible to enter
commands until the buffer partially empties, the CTS line is raised
again, and LED 7 stops flashing. If the terminal program ignores the
state of the CTS line and the buffer overflows, LED 2 flashes at a 2-Hz
rate and continues flashing until the modem switches from transmit to
receive.

If a speaker or headphones is connected to the speaker jack, use the d5
command to monitor the modem baseband signal. A properly tuned in RTTY
signal will produce a distinct "tick-rumble" signal sounding vaguely
like a Teletype Model 12 (which is not completely accidental). The tick
is produced when a valid start bit has been found; the rumble is
produced as each bit of the signal is processed. With practice, signals
can be tuned in accurately by watching the LEDs and listening with the
d1 and d5 commands on the speaker. For instance, an improperly tuned in
or malformed signal may produce no tick, an irregular tick, or a weak or
nonexistent rumble.

In RTTY operation, an autostart function can be used to avoid messy
garbles when a RTTY signal of sufficiently good quality is not being
received. (In SITOR mode, these functions are intrinsic in the signal
and protocol design.) The a{0-1} command is used to select the autostart
mode. In the a0 mode, which is the default, output is blocked, unless
the signal level of either the mark or space channel is above the
carrier threshold (c{+-} command) and the character quality estimate
(distance) is above the erasure threshold (v{+-} command). In the a1
mode, output is blocked until a continuous spurt of about ten correctly
framed RTTY characters is received with a quality estimate above the
autostart threshold (a{+-} command). Once a spurt is received, a 30-s
timer is started and begins counting down. Any character received while
the timer is running resets it to 30 s. If no characters are received
before it runs out, output is again blocked and LED 4 flashes at a 1-Hz
rate.

In SITOR operation, the modem sensitivity is such that good copy can be
made with signals that cannot be reliably detected by ear with a SSB
voice receiver. This includes signals buried in noise or interference,
where the LEDs and speaker are generally useless as tuning indicators.
Even a scope connected to the detector output (d5 command) may not help
much. Therefore, tuning in such signals requires some ingenuity. The
most useful technique may be using the d8 command and a DVM or DC-
coupled scope connected to the AIO output. The output is about 2V with
no input signal and decreases with increasing input signal and signal
quality. When the output decreases below zero, the modem should be
synchronized and delivering copy. The output is particularly sensitive
to the CCIR retrain sequence (see below for more information on this
sequence). This sequence, which normally is sent at the end of each line
or when no traffic is available, produces a strong negative voltage
excursion when received.

If all you want to do is plug-'n-play with this thing as an ordinary
TNC, you can probably skip reading from here to the command summary near
the end. However, the modem was designed specifically to suck weak
signals from the electrical noise, multipath propagation and cochannel
interference typically found on the HF amateur bands. If you are
intrigued, read the following sections, which describe the features
designed to optimize the modem performance under these conditions.

Filtering and Limiting Functions

There are two input order-70 bandpass FIR filters implemented in the
modem, a 450-Hz bandpass filter for narrow 170 Hz shift and a 1100-Hz
bandpass filter for wider shifts to 850 Hz. These filters, which  were
designed using the Remez method and the Math Works, Inc., Matlab Signal
Processing Toolkit, have steep skirts and a maximum stopband ripple of
50dB. Following the adjustable limiter, there are two sets of channel
filters, one implemented as a synchronous lowpass matched filter, the
other as a synchronous lowpass IIR filter. Separate filters are
implemented for each of the mark and space channels. These are selected
using the m{1-8} command for various shifts and filter combinations.

The order-2 Butterworth IIR lowpass filters (m{1-4} command) are useful
under most operating conditions with RTTY signals and shifts wider than
170 Hz. These filters, which were designed using the bilinear-transform
method and the Math Works toolkit, are narrow enough for good
performance, but wide enough at about 300 Hz for easy tuning. In this
case, postdetection matched filters are used in both the mark and space
channels to optimize the transient response and as an interpolation
filter. Alternatively, synchronous predetection matched filters (m{5-8}
command) can be used for greater selectivity with RTTY and SITOR signals
at all shifts. In this case, postdetection filters are not necessary.
The matched filters are matched to the baud rate and have bandwidths
approximately equal to twice the reciprocal of the baud rate. In the
case of the synchronous predetection matched filter, this makes tuning
very sensitive, especially at the lower baud rates, and requires, for
example, an adjustment for TNCs with compromise 200-Hz output tone
shift. At the lowest baud rate of 10 baud, the receiver must be
accurately tuned and remain stable to within a few Hz.

A transient clipper is located at the input to the modem before the
input bandpass filter. Its intent is to kill noise spikes that might
ring and overload later stages in the modem, but has no significant
affect at ordinary signal levels. LED 1 flashes if the clipping level,
which is about 10dB below modem overload, is exceeded. The analog gain
of the modem can be adjusted from unity in steps of 6dB (g{0-7}
command). A variable gain limiter is implemented between the input
bandpass filter and the synchronous lowpass filters. The l{0-5} command
can be used to select limiter gain from 0 to 30dB in 6dB steps. The i
command can be used to invert the detector signal for upright/inverted
shifts. The c{0-2} command can be used to disable either the mark
channel or space channel, if required to eliminate interference. Gain
factors for all combinations of filters have been optimized for most
conditions. However, the system gain following the limiter can be
adjusted using the g{+-} command. This may be useful when operating with
low level signals with the limiter switched off.

Signal Quality Processing

The modem implements three signal quality estimators based on measured
characteristics of the mark and space baseband signals and decoded
characters. There are called the carrier distance, erasure distance and
autostart distance. The carrier distance is developed directly from the
baseband signal and recomputed at the sample rate, which occurs at eight
times the baud rate. The erasure and autostart distances are developed
from measurements made by the RTTY and SITOR decoders and recomputed at
the character rate. Associated with each of these three estimators is a
threshold, which may be set by a designated command, and a gate, which
indicates whether the distance is above or below the threshold.

The primary function of the carrier distance is to provide a gate for
the RTTY decoder, in order to avoid extraneous signals which can yield
no useful output. However, these signals are also available with the
SITOR decoder for use as a tuning aid. The carrier distance is developed
using two 192-stage shift registers operating as boxcar integrators and
two 4-stage shift registers operating as sample classifiers. At each
baseband sample time, the mark and space channel signals are sampled. If
the mark channel signal exceeds the space channel signal by a factor of
at least two (6dB), the mark signal is classified a carrier sample and
the space signal classified a noise sample. Similarly, if the space
channel signal exceeds the mark channel signal by a factor of at least
two, the space signal is classified a carrier sample and the mark signal
classified a noise sample. If neither of these two cases is true, both
the mark and space channel signals are classified as noise samples.

The carrier samples and noise samples are shifted through separate
classifier shift registers in order to delete outlyers and modulation
products. The carrier signal is represented by the maximum sample in the
carrier classifier register, while the noise signal is represented by
the minimum sample in the noise classifier register. The carrier energy
(carrier signal squares) and noise energy (noise signal squares) are
separately integrated over 192 samples (about three characters) using
the boxcar integrators. Finally, the carrier distance is computed as the
carrier energy minus the noise energy. If this distance exceeds the
carrier threshold set by the c{+-} command, the carrier gate is
unblocked.

Signal samples are classified as mark and space using a 64-stage
survivor shift register. At each baseband sample time, the detector
differential (mark minus space) signal is shifted through the register
and the maximum (positive) and minimum (negative) of this signal
determined over all 64 samples in the register. The slice level is
established midway between the maximum and minimum values. Signals above
this level are classified as mark samples, while those below this level
are classified as space samples.

A character quality estimate called the erasure distance is developed by
the RTTY and SITOR decoders. As each character or word is decoded, a
quality function is developed based on the Viterbi algorithm (RTTY
decoder) or correlation function (SITOR decoder), as described later. In
addition, the detector differential signal squares are computed over all
samples in the survivor register. The erasure distance is computed as
the ratio of the mean quality function over the RMS differential signal.
If this distance exceeds the erasure threshold set by the v{+-} command,
the erasure gate is unblocked.

The autostart function blocks and unblocks the decoder output as
determined by a set of sanity checks and the erasure distance. It
operates as a gate to avoid garbles due to noise and signals other than
RTTY or SITOR and is primarily intended for use in a crossband repeater,
where reliable signal detection is essential. The RTTY decoder uses the
autostart gate to determine when to switch between asynchronous and
synchronous modes (if enabled by the s command). The SITOR decoder uses
the autostart gate in order to distinguish between noise and a correctly
synchronized character stream.

The autostart distance is computed from two signals generated by the
RTTY and SITOR decoders, as described in the sections below for each
decoder. One of these signals is derived from the quality function
developed by the decoder, while the other is the detector differential
signal squares developed during the erasure distance calculation. The
related autostart signals are developed from these signals integrated
over a period of 15 characters using a pair of shift registers operated
as boxcar integrators. The autostart distance is computed as the ratio
of the mean quality function over the RMS differential signal. If this
distance exceeds the autostart threshold set by the a{+-} command, the
autostart gate is unblocked.

Including the integration performed while developing the erasure
distance, the autostart distance is integrated over a total of 960
baseband signal samples, which gives it a fair degree of authority in
separating valid characters from noise. In the RTTY decoder, the a{0-1}
command selects the signals and gates used to control the autostart
function, as described below. In the SITOR decoder, the a{0-1} command
is not useful, since the extensive integration and correlation
procedures are sufficient to avoid garbles without additional gating
functions.

RTTY Decoder

The RTTY decoder is compatible with the ITA-2 (Baudot) character format
long used in the amateur and commercial communities. The Baudot
character format or codeword includes a start bit, which is always zero
(space), five data bits and a stop bit, which is always one (mark) and
usually 1.5 baud intervals in length. The decoder goes to some extremes
in order to reliably extract RTTY characters under conditions of low
signal levels, high noise levels and severe multipath conditions.
Experience has shown the most important factor for good decoder
performance is reliable detection of the start bit. The decoder saves
eight differential signal samples for each of eight baud intervals, a
total of 64 samples, in the survivor shift register. These samples are
used to determine the maximum and minimum amplitudes and slice level for
the detector differential signal, as described previously.

The oldest bit in the shift register is the stop bit of the previous
character, the next oldest bit is the start bit of the current
character, and the youngest is the stop bit of this character. A
survivor is defined as the vector of samples beginning in the oldest bit
and extending through the corresponding sample of each bit in turn to
the youngest bit. There are eight survivors, one beginning for each
sample in the oldest bit. The problem is to identify whether the oldest
sample in the start bit begins a character and which of the eight
survivors represents the most likely transmitted signal.

The RTTY decoder can operate in two modes, asynchronous and synchronous,
depending on signal quality and operator preference. (SITOR operation is
always synchronous.) In asynchronous mode, which is the default, a
character can arrive at any time and is decoded independently. As each
new signal sample is received, a series of checks is performed to
determine if the survivor ending in this sample begins a character. Only
those survivors which meet the following criteria are eligible: (a) the
carrier gate is unblocked, (b) in the last eight bit times, the oldest
bit (stop bit of the previous character) is classified a mark, (c) the
next oldest bit (start bit of the current character) is classified a
space, and (d) the youngest bit (stop bit of the current character) is
classified a mark. Unless all of these criteria are met, the decoder
discards the current survivor and waits for the next sample.

If the criteria are met, the distance for each survivor ending in the
last bit interval of the survivor register is computed according to the
Viterbi algorithm. Survivors that do not show mark in the stop bits and
space in the start bit are ignored. Of the remainder, if there are any,
the one with maximum distance represents the most likely character as
transmitted. Note that the distance as used here is the negative of the
usual Viterbi distance, in that it increases with increasing
probability. The maximum distance represents the quality function used
in computing the erasure and autostart distances. This is the basis of
the MAP claim, since of the 256 eight-bit words that might be received,
only those 32 words which satisfy the above criteria have nonzero a-
priori probability. The survivor with maximum distance is then delivered
to the common output buffering routine described below.

The operation of the carrier and autostart gates in RTTY asynchronous
mode has been described previously. While the false-alarm rate using
only the carrier gate can be rather high, the false-alarm rate using the
autostart gate is much lower. For this reason, the operator should send
a continuous burst of ASCII SYN characters (which are translated to
Baudot LTRS characters) in RTTY asynchronous mode, or wait a couple of
seconds in RTTY synchronous mode, when beginning transmission to allow a
receiver known to be using the a1 command to be unblocked. The autostart
gate is designed for long periods of inactivity, such as when the system
is waiting for a selective call and it doesn't matter if a few
characters are lost at the beginning of transmission. During a
continuous period of activity, the autostart gate has only marginal
usefulness.

In RTTY synchronous mode, the modem phase-locks to the start-bit
transitions of a continuous sequence of characters. The decoder thus
operates as a gated receiver, with the PLL signal derived only from the
samples corresponding to start-bit intervals. This improves performance,
especially under multipath conditions resulting in deep fades of either
the mark or space channels or both. In such cases when valid character
framing is lost, the decoder simply scraps the garble without losing
valid framing for subsequent characters.

The phase error is the signal at the oldest sample in the start bit,
which is exponentially averaged to form the error signal used to drive
the critically damped PLL, which has a time constant of about 2 s. This
assumes that the modem has first estimated the intercharacter time in
asynchronous mode. To do this, the intercharacter time estimate is
determined as the exponential average of the number of samples since the
last start bit. The intent is to provide a seamless transition between
asynchronous and synchronous operation. In order for the estimate to be
updated, the intercharacter interval must fall within a window of four
samples centered in the eighth bit, which provides protection against
severe jitter due, for example, to extreme bias shifts in deep multipath
fades.

The decoder starts in asynchronous mode and refines the intercharacter
interval estimate as valid characters arrive in a continuous stream.
Eventually, if the signal quality is good enough, the autostart gate is
unblocked. If enabled by the s command, the modem automatically switches
to the synchronous mode and LED 4 is turned on continuously. Operation
in synchronous mode continues until the autostart distance falls below
the threshold, indicating the signal quality has deteriorated or phase
lock has been lost, in which case the modem automatically switches to
asynchronous mode. When transmitting in synchronous mode, the
transmitter sends an idle character (LTRS) if the transmit buffer is
empty and neither a ACK or EOT has been received from the terminal
program. This helps the remote station maintain synchronization during
pauses when no text is being transmitted.

SITOR Decoder

The SITOR decoder is compatible with the CCIR 476 Mode B (FEC) character
format and protocol used in both commercial (SITOR) and amateur (AMTOR)
operations. The decoder is an unusual design based on correlation and
maximum-likelihood principles. In fact, the decoder never makes a
decision based on classifying bits as marks or spaces. Rather, an
approach based on soft decisions is carried through all processing
steps, with the final decision based on a correlation of a 14-bit word,
consisting of a received seven-bit character and its repetition, with
each of the 35 CCIR codewords. The one with maximum correlation function
wins and the function value (normalized by the RMS detector signal over
the word) becomes the erasure distance. A design such as this represents
the optimum receiver for equiprobable source symbols transmitted over
nonfading or Rayleigh fading channels with additive white Gaussian
noise.

The CCIR character format consists of seven bits, four of which must be
one (mark) and three zero (space). In Mode B operation, the fifth
character following a transmitted character is a repetition of that
character. The error performance of this scheme can be analyzed as
follows. Since all 35 seven-bit CCIR characters have weight four, the
seven -bit CCIR code has minimum distance two. The 14-bit code,
consisting of vectors of two identical CCIR characters, has minimum
distance four, thus can correct all single-bit errors and in addition
detect all two-bit errors.

An error-free CCIR codeword has a correlation function of 14, while its
bit complement has a function of -14. A single bit error in one of the
two CCIR characters results in a maximum function of 12 and is
correctable. A two-bit error results in a maximum function of 10 and is
not necessarily correctable. This could occur if each of the two
characters had weight four, but were distance two from each other. In
order to reliably correct single-bit errors, yet reject all others, the
optimum decoder threshold should correspond to function values between
10 and 12, depending on the intended ratio of missed detection and false
alarms.

A transmitted character and a replicated character from a previous
transmission are transmitted as one 14-bit word. Words are transmitted
continuously; if no characters remain to be transmitted, the two-
character synchronization word RQ-ALPHA is transmitted. In addition, at
intervals of about ten seconds, five repetitions of this word are
transmitted as a retrain sequence, in order to allow reliable receiver
resynchronization and avoid receiver buffer overrun.

A short description of the CCIR 476 signal design may help clarify the
encoder operations. The encoder uses a three-word shift register, of
which the least significant 14 bits of each word represent the CCIR
codeword. The least significant seven bits of the first word represent a
new character, while the next most significant seven bits represent the
repetition of the fifth character in the past. The figure below shows
the progression of the sequence "abc", where the least significant seven
bits in all but the first word are not used. It begins with the
synchronization word RQ-ALPHA (RQ-ALF) with transmission to the right.

          +---+---+   +---+---+   +---+---+   +---+---+   +---+---+
  word 3  |ALF|   |   | a |   |   | b |   |   | c |   |   |ALF|   |
          +---+---+   +---+---+   +---+---+   +---+---+   +---+---+
  word 2  |ALF|   |   |ALF|   |   | a |   |   | b |   |   | c |   |
          +---+---+   +---+---+   +---+---+   +---+---+   +---+---+
  word 1  |ALF|RQ |   |ALF| a |   |ALF| b |   | a | c |   | b |RQ |
          +---+---+   +---+---+   +---+---+   +---+---+   +---+---+

Note that a 14-bit CCIR codeword is 140 ms in length at 100 baud (10 ms
per bit), while a standard 7.5-bit Baudot character is 150 ms in length
at 50 baud (20 ms per bit). Thus, an unrestrained CCIR transmitter gains
10 ms per character over a standard Baudot printer operating at 75 baud.
To avoid overrunning the receiver buffer, the transmitter inserts the
retrain sequence after 70 ordinary codewords have been transmitted.
Insertion continues indefinitely as long as characters remain to be
transmitted.

When the SITOR decoder routine is called, the last eight bits (64
samples) are in the survivor shift register, in order to determine the
maximum and minimum signal amplitudes and slice level, which is used to
remove bias shift due to unequal mark and space channel amplitudes. The
bit phase is extracted from the eight samples in the first bit of the
register using a linear phase detector. If the signal polarities at the
beginning and end of this bit are opposite, the signal value at the
midpoint of the bit is likely a good measurement of bit phase. This
value is exponentially averaged to drive a critically damped, type-I PLL
with a time constant of about two seconds. This PLL controls the bit
phase independent of character synchronization. The quadrature-phase
samples are used to derive the VCO signal, which is implemented by
modulating the bit sample interval. The in-phase samples are corrected
for bias shift and shifted through a six-character (42 bit samples)
shift register to be used later.

Word synchronization is determined by correlating characters in the
original and repeat position of the received word with the CCIR retrain
sequence, which is normally transmitted at the end of each line of text
or 70 characters, whichever occurs first. The correlation function is
continuously measured for each of 14 bit positions and averaged over all
five words (70 bits) of the sequence. The value of the function is the
quality function used to compute the erasure and autostart distances.
When the autostart distance exceeds the threshold set by the a{+-}
command, correct character phase has been achieved and characters are
output to the terminal program. The processing gain achieved by this
method (over 18dB) is enough to provide reliable synchronization without
consideration of the carrier distance, even under marginal conditions
with relatively high bit error rates.

Once the retrain sequence has been detected, the most likely decoded
character is determined using a correlation process. In the normal case
(other than the retrain sequence), the original and repeat characters
are the same, so can be vector summed before correlation. This is done
using the first and last character of the six-character shift register
mentioned previously. Since the RQ-ALPHA word does not involve a
replicated character, it must be correlated separately. The correlation
process is somewhat tricky in view of the limitations of the TMC320
signal processor and is done as follows.

The 42-bit shift register developed by the baseband processing routines
is stored in program memory in the coefficient page, while the
correlation coefficients are stored in data memory. The decoding routine
correlates the vector sum of the seven-sample original character code
plus the seven-sample repeat character code (delayed five characters)
with each of the 35 possible seven-bit CCIR codewords and selects the
one with maximum correlation function. Its value represents the quality
function used to construct the erasure distance. If the erasure distance
exceeds the threshold set by the v{+-} command, the codeword is
translated to Baudot and delivered to the common output buffering
routines described below.

Transmitter Signal Generation

The transmitter signals for both RTTY and SITOR are synthesized AFSK
audio sinewaves at the programmed mark and space frequencies, as
described in the command summary. In addition, a PTT signal is developed
to control the transmitter carrier. Signal generation involves three
steps, switching and buffering data from either the terminal program or
decoder, as described below under Half/Full-Duplex Modes, encoding the
keying waveform, and generating the AFSK output signal.

Separate encoders are used for RTTY and SITOR, but they operate in much
the same way. ASCII characters to be transmitted are translated to
Baudot (and then to CCIR 476 code in case of SITOR) and encoded for
transmission using a shift register. The mark/space signal is generated
using the bit-rate clock developed by the decimation schedule. Finally,
the mark/space signal is used to synthesize the AFSK output signal using
a table of sine-function values at three-degree increments.

Both encoders implement a request-to-send (RTS) delay, in order to allow
receivers to synchronize in the synchronous-RTTY and SITOR modes, while
the SITOR encoder inserts the retrain sequence every 70 transmitted
Baudot characters to avoid overrunning the receiver buffer and to
provide retrain opportunities. The encoders also provide idle fill, in
order to provide continuous timing in synchronous modes - LTRS in the
RTTY encoder, a RQ-ALPHA word in the SITOR encoder.

Character Buffering, Translation and Unshift Operations

Baudot characters delivered by the RTTY and SITOR decoders are processed
by a common output routine, which implements various gating and
translation functions and switches the output to the input and output
buffers as determined by duplex mode (e{0-3} command), as described
below. If the SITOR decoder is in use, or if the RTTY decoder is in use
and operating in synchronous mode, output is blocked if the autostart
gate is blocked. If unblocked and the erasure gate is unblocked, the
character is translated to ASCII and delivered to the input or output
buffer, as indicated by duplex mode. If the erasure gate is blocked, the
erasure character "_" is delivered instead, unless suppressed by the
v{0-1} command. In RTTY asynchronous mode, the gating protocol is
controlled by the a{0-1} command, as described previously. In this case,
output is blocked if the erasure gate is blocked.

There are two sets of character buffers, one for input from the terminal
program, the other for output to the terminal program. Each is
implemented as a circular buffer of 1000 characters maximum size. The
flow control functions depend on the number of characters remaining in
the buffer. When less than one-third of the maximum size remains, the
buffer is said to be in the red condition. In this condition the CTS
line is dropped by the UART used by the terminal program. When more than
two-thirds of the maximum size remains, the buffer is said to be in the
green condition. In this condition the CTS line is raised, permitting
the terminal program to send additional data. As noted previously, when
the CTS line is dropped, the terminal program is blocked not only from
sending data to be transmitted, but from sending commands as well.

As evident from actual operations, not all hardware and software
configurations can respond to the CTS signal in time to prevent
occasional buffer overrun when transmitting a long file, at least when
operating at speeds of 19,200 baud with the Windows 3.1 Terminal program
and a 50-MHz 486 processor. There is no provision in the present
implementation to change the UART baud rate. An appropriate future
enhancement would be an autobaud function similar to that implemented in
some conventional computer modems.

The native interchange code used by both the RTTY and SITOR
encoder/decoder is Baudot (ITA-2), while the native interchange code
used by the terminal program is ASCII (ITA-5). The modem implements the
Baudot and ASCII code translation tables to conform to conventions
established by the international community as represented by tables in
the ARRL Handbook, 1995 Edition. ASCII characters to be translated are
first stripped of the parity bit, then mapped to upper case. Except for
the following, all ASCII characters with undefined Baudot equivalents
are discarded before translation.

     ASCII   Baudot Function
     -------------------------------------------------------
     EOT    LTRS    close down transmitter immediately
     ACK    LTRS    close down transmitter when buffer empty
     ENQ    WRU     trigger answerback at receiver
     SYN    LTRS    use for fill if necessary

On transmit, Baudot CR and LF characters are forced to LTRS shift, in
order to improve copy under marginal conditions. If enabled by the u{0-
2} command, a SP (space) character is forced to LTRS shift for the same
reason. On receive, if enabled by the u{0-2} command, a SP character is
interpreted as if the sequence LTRS-SP were transmitted. Another set of
code translation tables is used to translate between the Baudot
interchange code and the CCIR 476 transmission code used by the SITOR
encoder/decoder. The Baudot-to-ASCII, ASCII-to-Baudot and Baudot-to-CCIR
tables are hard coded in the modem program; however, the CCIR-to-Baudot
table, which consists of 35 seven-sample code vectors, is built during
reset processing directly from the Baudot-to-CCIR table.

Half/Full-Duplex Modes
The modem can operate in four modes: half-duplex regenerator, analog
loopback echo and digital loopback echo modes, and full duplex mode. The
e{1-1} command is used to switch between these modes. The configuration
of the modulator and demodulator units and their associated buffers in
each mode is described the following paragraphs.

Receive regenerator mode (e1, e2) is used during receive for the half-
duplex analog loopback echo (e1) and digital loopback echo (e2) modes.
The configuration in this mode is shown in the following diagram.

             +---------------+
             |               |    +------+
     AFSK -->+  Demodulator  +-+->| FIFO |--> Receive
             |               | |  +------+
             +---------------+ |
                               +------------+
             +---------------+              |
             |               |    +------+  |
     AFSK <--+   Modulator   +<---+ FIFO |<-+
             |               |    +------+
             +---------------+

When operating as a regenerator, an ordinary TNC is connected to the
AFSK output and used to demodulate and decode the regenerated signal.
The regenerator demodulates the input signal, converts to ASCII, then
converts back to Baudot and generates the output AFSK signal. The
conversion removes extraneous nonprinting characters and regenerates
LTRS and FIGS control characters, including a LTRS character following
CR/LF. The regenerated tones can also be used to drive a transmitter or
crossband repeater.

In transmit analog loopback echo mode (e1), characters are echoed as
actually sent. The configuration in this mode is shown in the following
diagram. There is a variable delay in this mode, depending on how far
ahead the typist is of the transmitted signal. Note that there is an
additional fixed delay of five characters in SITOR mode.

             +---------------+
             |               |    +-------+
          +->+  Demodulator  +--->| FIFO  |--> Echo
          |  |               |    +-------+
          |  +---------------+
          |
          |  +---------------+
          |  |               |    +-------+
   AFSK --+--+   Modulator   +<---+ FIFO  |<-- Transmit
             |               |    +-------+
             +---------------+

In transmit digital loopback echo mode (e2), characters are echoed as
received from the terminal program. The configuration in this mode is
shown in the following diagram. Note that the demodulator is not used,
other than to drive the various monitor LEDs.

             +---------------+
             |               |    +-------+
          +->+  Demodulator  | +->| FIFO  |--> Echo
          |  |               | |  +-------+
          |  +---------------+ |
          |                    +-------------+
          |  +---------------+               |
          |  |               |    +-------+  |
   AFSK --+--+   Modulator   +<---+ FIFO  |<-+-- Transmit
             |               |    +-------+
             +---------------+

In full-duplex mode (e3), the modulator and demodulator, together with
their buffers, are functionally separate. No provisions for echo are
made. The configuration in this mode is shown in the following diagram.

             +---------------+
             |               |    +-------+
     AFSK -->+  Demodulator  +--->| FIFO  |--> Receive
             |               |    +-------+
             +---------------+

             +---------------+
             |               |    +-------+
     AFSK <--+   Modulator   +<---+ FIFO  |<-- Transmit
             |               |    +-------+
             +---------------+

Note that in the transmit analog and digital loopback modes, the
modulator and demodulator must be operated with the same shift and
mark/space polarity, which is possible only with the 170-Hz and 850-Hz
shifts.

Implementation Overview

This section contains a brief overview of the modem program
implementation. It is designed to assist in understanding of the various
operations and principles described herein, as well in possible
modifications of the source code that may be useful in practice. The
program itself, which is in assembly code and richly commented, is the
ultimate functional reference. As these programs go, this one is on the
large side, over 7000 words of program memory and over 7000 words of
data memory.

The basic program design consists of a main program, which operates with
interrupts enabled, a set of minimalist interrupt routines, and a
circular buffer which holds analog input and output samples. Input
samples received from the A/D converter interrupt routine are saved in
the circular buffer pending retrieval by the RF input routine, while
samples generated by the RF output routine are saved in the same buffer
pending retrieval by the D/A converter interrupt routine.

There are two pointers to the circular buffer, a get pointer used by the
interrupt routines and a put pointer used by the RF input and output
routines. The A/D interrupt routine stores an input sample at the
current get pointer position and advances the pointer. The D/A interrupt
routine reads the sample at the current get pointer position, which is
delayed from the input sample by the number of samples in the buffer
times the sample interval, 125 us.

The RF input routine reads the sample at the current position of the put
pointer, which is usually not far behind the get pointer. For every
input sample, the program produces an output sample, which is stored by
the RF output routine at the put pointer position and the pointer
advanced. While the put pointer can occasionally lag behind the get
pointer due to code latencies, every input sample is replaced by a
output sample corresponding to a fixed delay. Thus, the buffer serves as
an elastic delay line, giving the main program considerable leeway in
code latencies. Since the input and output interrupts are synchronous
and every input interrupt results in exactly one output interrupt, no
data are lost or duplicated, unless the latency exceeds the maximum
delay in the buffer, in which case a slip equal to the entire buffer
contents occurs.

The program operates at a basic rate of 8000 Hz, corresponding to the
sample rate of the A/D and D/A converters. Due to the choice of master
oscillator frequency and the programmed divider configuration of the
converters, the nearest actual rate is 7947 Hz; therefore, it is
necessary to slip an occasional sample interval in order to closely
approximate the 8000 Hz sample rate with a resolution better than 15
PPM. At this rate, the program implements the predetection filtering,
limiting and demodulation functions to develop the mark and space
channel signals used by the baseband routines. The RTTY and SITOR AFSK
signals are also generated at this rate.

The output of the filter/limiter stages is multiplied by sine and cosine
functions separately for both the mark and space frequencies, making
four filter channels in all. Identical lowpass filters are used for each
channel, one for the in-phase component, the other for the quadrature-
phase component. After filtering, the two components for the mark
channel are squared and summed, then the two components for the space
channel are squared and summed. The detector output signals for the mark
and space channels are generated by a square-root routine using three
iterations of the Newton-Raphelson algorithm. For the predetection
matched filters, the output of each channel is taken at this point. For
the IIR filters, the output at this point is filtered by a matched
filter operating at baseband, both to provide the required impulse
response and also to act as a decimation filter.

The predetection matched filters and the postdetection matched filters
used with the IIR channel filters are matched to a rectangular pulse of
duration equal to a bit interval. In the predetection case, four filters
are used, one each for the I and Q phase of the mark and space channels.
They are implemented using a circular buffer with the four samples
interleaved in sequence. There are two reasons for this. First, the
filters can grow quite large - up to 3000 samples at a 10-Hz baud rate -
which would make a transverse filter of the FIR type impractical.
Second, only a limited amount of memory is available for shift registers
and coefficients in the TMC320. The same structure is used for the
postdetection matched filter, but only two samples are necessary for
each cycle.

There are three decimation clocks used in the modem, one at the nominal
sample rate, which is eight times the baud rate, another at the baud
rate and a third at the character rate of the decoder. The baseband
processing routines operate using the sample clock to operate the
survivor shift register, determine the maximum mark and space channel
signal estimates, and calculate the carrier distance. The RTTY and SITOR
decoders also operate using the sample clock to decode the characters
and provide the character clock. In the case of the SITOR decoder, the
sample clock is modulated to provide the VCO function for the PLL, which
explains the use of "nominal" above.

The baseband signals and signal quality estimators are determined using
the sample clock, in order to realize convenient filter structures and
reduce the processing burden. The functions provided at this level are
described above under Baseband Processing above. However, as the sample
clock is variable over a small range, in order to track SITOR symbol
phase, this clock is inappropriate to drive the SITOR encoder, since
this needs a precision source of timing. Thus, the bit clock for the
SITOR encoder is developed separately.

The autostart functions based on Viterbi distance use the character
clock developed by the decoders themselves. The character translation,
character buffering and related functions are driven by the decoders and
thus also operate at this rate.

The 2x14 integrators used for SITOR character phase resolution consist
of two sets of 14 interleaved matched filters stored in a circular
buffer. One set consists of 14 matched filters, where the impulse
response is matched to the 70-bit sequence consisting of five
repetitions of the CCIR sync codeword RQ-ALPHA. The other set consists
of 14 boxcar integrators used to sum the squares of 70 carrier samples
for use as a normalizing function. As each bit is received, the erasure
distance is calculated as the ratio of the matched filter output to the
square root of the boxcar integrator output.

The matched filter operations in the SITOR decoder are implemented using
correlation techniques. The correlation function is stored in the form
of an array of vectors in the order corresponding to the Baudot code
equivalents. Each vector has seven bipolar components selected according
as to whether the CCIR code has a one or zero in the corresponding bit
position. The components are scaled so that the peak of the correlation
function is equal to the maximum of the input signal. The organization
is such that a pipelined multiply-and-add function can be embedded in a
tight loop that scans the vectors one after the other looking for a
maximum. This loop takes 35 iterations of 18 machine cycles for a total
of 630 cycles per character, or about 5.6% of the available cycles.

The 42-bit shift register used in the SITOR decoder is implemented in
program memory in the coefficient page, rather than in data memory as
would normally be expected. The reason for this is that there are too
many correlation coefficients (230) to fit in the internal data memory
and the CPU architecture requires the coefficients and data memory to be
on different busses for maximum pipeline efficiency. Therefore, the
coefficient page is mapped to data memory in order to shift new samples
into the delay line and mapped to program memory before correlation.

There are generally spare cycles left over when all processing for an
input sample is completed. The program uses these cycles for
housekeeping functions, such as running the intricate LED display
program, looking for terminal program input and output data, searching
for command input and so forth.

Many functions of the program make use of what are called boxcar
integrators. These data structures consist of a circular buffer, a
buffer pointer and an accumulator. A new signal sample is introduced by
first subtracting the old sample value in the buffer at the pointer
position from the accumulator and storing the new sample at this
position. Then, the new sample value is added to the accumulator and the
buffer pointer advanced. The accumulator thus contains the sum of all
samples in the buffer.

Boxcar integrators are used in the program to implement the matched
filter operations and to compute the various distance functions. They
are simple to implement, can be made quite large, e.g., 3000 words in
the predetection matched filters, and use relatively few processor
cycles. They can be easily multiplexed, e.g., 2x2 in the predetection
matched filters and 2x14x5 ways in the SITOR word synchronization
matched filter.

Most of the signals processed are in fractional q15 format, where the
decimal point is immediately behind the sign bit. The processor is
operated in sign extension mode (SXM), overflow mode (SOM), where
overflows are clamped to the largest or smallest integer representation,
and product mode (SPM 1), where the results of a multiplication are
left-shifted one bit before transfer to the accumulator. These
conventions simplify the arithmetic operations and help preserve
significance. Product accumulations, VCO frequencies and some critical
data are maintained in multiple precision (32 bits).

Only a few interrupt-related program variables are in internal data
memory block B2, while filter coefficients and some delay lines are in
internal memory block B0, which is usually mapped to program memory. The
remaining delay lines are in internal data memory block B1. Most of the
working variables are in the user page (8) accessed by direct addressing
modes. Arrays, shift registers and accumulators accessed by indirect
addressing modes follow the working variables.

Performance Example

Following is an example comparison of a SITOR broadcast from AT&T Miami
Radio WOM, which sends ship traffic lists, information and weather
forecasts on a regular basis. This particular broadcast was purposely
selected as representing marginally acceptable copy for amateur service.
There are two copies of the same message, the first decoded by the
digital modem described in this memorandum, the second decoded by the
AEA PK-232 TNC, which is typical of multipurpose analog modems. Both
modems were connected to the same SSB voice receiver. In both cases, the
"_" character represents an erasure where an uncorrectable error was
detected. The messages have not been edited in any way, except some
lines that spilled past the right margin have been folded to fit on
these pages.

Most would probably agree that the digital modem copy is significantly
more intelligible than the analog modem copy. A count of erasures shows
60 in the digital copy, 224 for the analog copy. In most cases where
obvious errors have occurred in the analog copy, the digital copy is
apparently correct; however, there are a few cases where obvious errors
have occurred in the digital copy and the analog copy is apparently
correct.

Digital Modem

CQ CQ CQ DE WOM WOM WOM
NATIONAL WEATHER SERVICE FORECAST RELAYED BY AT+T STATION WOMAQ
FOLLOWS:
_PY___AOOT 04:41:10 UTC



NATIONAL WEATHER SERVICE MIAMI FL
1130 PM EDT TUE JUN 27 1995
CARIBBEAN SEA AND SW N ATLC BEYOND 50 NM FROM SHORE.
.CARIBB_AN SYNOPSIS...NO SIGNIFICANT WEATHER FEATURES.
NW CARIBBEAN N OF 15N AND W OF 75W
.TONIGHT...S _F 17N WIND E 15 TO 20 KT. S__S 5 TO 7 FT. N L 17N
_____QRND E 10 TO 15 KT. SEAS 3 TO 5 FT.
.WED...WIND E 15 KT. SEAS TO 5 FT. ISOLATED TSTMS.
.WED NIGHT...WIND E TO SE 10 TO 15 KT. SEAS 3 TO 5 FT. ISOLATED
TSTMS. SW CARIBBEAN S OF 15N AND W OF 75W.
___TONIGHT....S OF 11N AND W OF 80W WIND VARIAB__ 10 TO 1_ KT.
SEAS 5 FT. ELSEWHERE WIND NE 20 KT. SEA___I FT. WIDELY SCATTERED
TSTMS S OF 13N.
.WED...S OF 11C AND W OF 80W WIND VARIABLE 1___59 15 KT. SEAS 5 FT.
ELSE_HERE WIND E 20 KT. SEAS 8 FT. WIDELY SCATTERED TSTMS.
.WED NIGHT...WIND E TO _E 10 TO 15 KT. SEAS 5 TOV___!5. WIDELY
SCATTERED TSTMS MAINLY S OF 12N.
E CARIBBEAN_ _F _UTW.
.TONIGHT_MMMN OF 15N WIND E__PD KT. SEAY 5___5. S OF _
15 TO 20 KT. SEAS 5 TO 7 FT.
.WED...WIND E 15 KT. SEAS 5 TO 7 FT. WIDELY SCATTERED TSTMA MAINLY N
OF 15N./
#____3 ,8&#5.6___4, 3 10 TO _5 KT. SEAS TO 6 FT. ISOLATED TSTMS.
.OUTLOOK THU THROUGH SUN...LITTLE CHANGE.
SW N ATLC S OF 32N AND W OF 65W
.SYNOPSIS...WEAK HIGH P___ RIDGE FROM 22N 65W TO S FLORIDA __LL
_XR__REAT WWD INT_ GULF OF MEXICO AS BIOAD LO PRES AREA NEAR _EPEN 72W__
DRIFTS SB_M
S.TONIGHT__MMN OF 27N E OF 70W WIND E TO SE 10 KT. S_A___T FT.
ELSEWHERE N OF RIDGE WIND W TO NW 15 KT. SEAS 6 FT. S OF RI_G_ IND
SE 0 KT  EXCEPT V_CIABLE W OF 75W. SEES 4 FT. ISOLAT_D TSTMS.
.WED...N OF 25N E OF 70W WIND S TO SE 10 KT. SEAS 5 FT. ELSEWHERE N
OF RIDGE WIND W TO NW 10 TO 15 KT. SEAS TO 6 FT. S OF RIDGE WIND E
10  KT. SEAS 4 FT. ISOLATED TSTMS._.WED NIGHT...N OF 25N AND W OF 77W
WIND VARIAB___ 59 10 KT. SEAS 4
FT. E OF 77W WIND N TO NW 10 KT. SEAS 5 _T. S OF 25N WIND VARIABLE
5 TO 10 KT EXCEPT W OF 75W WIND NE 10 TO 15 KT. SEAS 3 TO 5 FT.
SCATTERED SHOWERS AND ISOLATED TSTMS MAINLY W OF 75W AND N OF 25N.
.OUTLOOK THU THROUGH SUN...HIGH PRES RIDGE WILL RESTABLISH ALONG 22N
AS LO PRES CENTER MOVES SLOWLY INTO N ATLC. N OF RIDGE WIND SW TO W
ABOUT 15 KT AND S OF RIDGE E ABOUT 10 KT. SEAS 3 TO 5 FT.
NNNN
-AR-

Analog Modem

CQ CQ CQ DE WOM WOM WOM
NATIONAL WEATHER SERVICE FORECAST RELAYED BY AT+T STATION________
_
FOLLOWS:
06___-_995 04:41:10 UTC



NATIONAL WEATHER SERVICE MIAMI FL
1130 PM EDT TUE JUN 27 1995
CARIBBEAN SEA AN_ SW N ATLC BEYOND 5_ NM FROM SHORE___
._AR__B_RN__YNOPSIS...NO SIGNIFICANT WEATHER FEATURES.
NW CARIBBEAN N OF 15N AND W OF 75W
__MTONIGHT...S OF 17N WIND _ 15 TO 20 KT._ ____5 TO 7 FT._N _F_17N
____R_Q__D E 10_ 59 15 KT. SEAS 3 TO 5 FT_
.WED...WIND E 15 KT. SEAS TO 5 FT. ISOLATED TSTMS.
.WED NIGHT...W_ND E TO SE 10 TO 15 KT. SEAS 3 TO 5 FT. ISOLATED
TSTMS. SW CARIBBEAN S OF 15N AND W OF 75W.___/_4_59,8&#5.__._ OF 11N AND
_ OF 80W WIND VA_IA_LR 10 TO 15 KT.
SEAS _ FT. ELSEWHERE WIND NE 20 KT. S___QI_ FT. WIDELY SCATTERED
TST_S S OF 13N.
.WED...S OF ____4$__ 2 9! 80W WIND VARIABLE____4_9_15 KT. _EAS 5 FT.
ELSE_HERE WIND E 20 KT. SEAS 8 FT. WIDELY SCATTERED TSTMS.
.WED NIGHT...WIND E TO _E 10 TO 15 KT. SEAS 5_ _____?&!5. WID_ZY__
SCATTERED TSTMS MAINLY S OF 12N.
E CARIBBEAN_ _F _UTW.
.TONIGHT_MM_N___ 15N WIND E__YW_ KT. SEAS_5___. S OF 15__ 28,$ 3
15 TO 20 KT. SEAS 5 TO 7 FT._
.WED...WIND E 15 KT. SEAS 5 TO 7 FT. WIDELY SCATTERED TST_A__AINLY N
OF 15____TM__E_ NIGHT____QG
_D E _QP TO 15 KT. S_AS TO 6 FT. ISOLATED TSTMS.
.OUTLOOK THU THROUGH SUN...LITTLE __A_GE._
__ , -5):  9! 32N AND W OF 65W
.SYNOPSIS...WE_K_HIGH_PR_H_RIDGE FROM 22N 65W TO S FLORIDA RPG___
RO_REAT W_N _NT_ GULF OF MEXICO AS _ROA_ _O PRES AR_A__EAR___R_N
72________
DRIF_S SDTM_
__MITONIGHT_._-_ 9! 27N E OF 70W WIND E TO S___P_KT. SEAR___ FT.
ELSEWHERE N OF RIDGE WIND W TO NW 15 KT. SEAS 6 FT. S OF__I_GE_WI_D
SE _Q_ KT  EXC__ _V___BLE W OF 75W. SE_S 4 FT. ISOLAT_D TSTMS.
.WED...__ 9! 25N E OF 70W WIND S TO SE 10 KT. SEAS 5 FT. ELSEWHERE N
OF RIDGE WIND W TO NW 10 TO 15 KT. SE_S_TO 6 FT. S OF RIDGE WIND E
10  KT. SEAS 4 FT. ISOLATED TSTMS.__.WED N_G_T_..___9! 25N AND W OF _UUW
WIND _AR_________ TO 10 KT. SEAS 4
FT. E OF 77W WIND N TO NW 10 KT. SEAS 5_ _._  9! 25N WIND VARIABLE
5 TO 10 KT EXCEPT W OF 7_W WIND NE 10 TO 15 KT. SEAS 3 TO 5 FT.
SCATTERED SHOWERS AND ISOLATED TSTMS MAINLY W OF 75W AND N OF 25N.
.OUTLOOK THU THROUGH SUN...HIGH PRES RIDGE WILL RESTABLISH ALONG 22N
AS LO PRES_CENTER MOVES SLOWLY INTO N ATLC. N OF RIDGE WIND SW TO W__
ABO_T 15 KT AND S OF RIDGE E ABOUT_10 KT_ SEAS 3 TO 5 FT.
NNNN
-AR-

Performance Analysis

In this section the performance of the DSP matched-filter modem is
compared to a conventional TNC, which uses analog filters. There are two
performance metrics of interest, signal-to-noise ratio (SNR) and word
error rate (WER). In the following, SNR is the ratio Es (energy per
symbol) to N0 (noise spectral density). Following standard conventions,
the noise is considered additive, white and Gaussian, in spite of the
practical experience that noise on HF circuits is usually far more
bursty than Gaussian.

In a matched filter, the output SNR is related to the input SNR

                       SNR(out) = 2 Ts B SNR(in),

where B is the input bandwidth over which SNR(in) is measured, B = 2100
Hz for a typical SSB communications receiver, and Ts is the integration
time. In the RTTY decoder at 50 baud with filters matched to the bit
interval, Ts = 20 ms, so the processing gain is 10 log(2 .02 2100) =
19.2dB. In the SITOR decoder at 100 baud with filters matched to the 14-
bit CCIR codeword as described previously, Ts = 140 ms, so the
processing gain is 10 log(2 0.14 2100) = 27.7dB. The method of finding
the character phase in the SITOR decoder involves coherent integration
over five repetitions of the CCIR sync codeword, Ts = 700 ms, so the
processing gain is a whopping 10 log(2 0.7 2100) = 34.7dB. These are
impressive figures, but probably misleading.

A more revealing comparison is the following. For the purposes of
comparisons, the baseband signal is assumed 100 baud for both the DSP
modem and conventional TNC and the limiter is switched off. By Carson's
rule, the bandwidth of a FSK signal with modulation bandwidth B and
modulation index beta can be approximated by

                          Bt = 2 (beta + 1) B.

For the 170-Hz shift used in SITOR and amateur RTTY, beta = 170 / 100 =
1.7. The required bandwidth can be approximated by the first null in the
baseband spectrum, which occurs at the baud rate for bipolar signals, so
B = 100 Hz. Thus, Bt = 2 (1.7 + 1) 100 = 540 Hz. Figures somewhat less
than this can be assumed if some degree of pulse shaping (ideally,
raised cosine) is used at the transmitter. Assuming a 500-Hz
predetection filter is used in the conventional TNC, the SNR following
the filter is improved about 6.2dB. A similar improvement, but with
better skirt selectivity, is provided by the FIR predetection filter in
the DSP modem.

Conventional TNCs use discriminator filters with bandwidths in the 300-
Hz range, which is also the case with the IIR filters in the DSP modem.
There is no appreciable improvement with these filters in either modem.
A good postdetection lowpass filter used in a conventional TNC might
have a 100-Hz cutoff for 100-baud signals, possibly less if pulse
shaping is used at the transmitter. Thus the best improvement that can
be expected of the filter is 10 log(500 / (100 sqrt(2))) = 5.5dB.
However, the optimal postdetection matched filter provides a processing
gain of 10 log(2 .01 500 / sqrt(2)) = 8.5dB, 3.0dB better than the
conventional TNC. On the other hand, the optimal matched predetection
filter has a processing gain of 10 log(2 .01 500) = 10.0dB, 4.5dB better
than the conventional TNC.

The probability of bit error, or bit error rate (BER), for a noncoherent
FSK channel is given by

                    Pe = BER = 1/2 exp(-Es/(2 N0));

or, solving for SNR,

                     SNR = Eb/No = 2 ln(1/(2 Pe)).
The word error rate (WER) for a word of N bits is WER = 1 - (1 - BER)^N,
assuming these errors do not affect the character framing. However, with
the RTTY decoder and the seven-bit Baudot code, it can be shown using
Markov models (unpublished memorandum) that the errors (slips) due to
framing are of a magnitude equal to those that do not affect the
framing. Therefore, the WER can be closely approximated by WER = BER /
(2 N) in the probability range of interest.

A goal of WER = 1e-4, corresponding to one character error for two lines
of print, can be considered an acceptable level for amateur service. For
a seven-bit RTTY character, this corresponds to BER = 1e-4 / 14. At this
BER and a noncoherent FSK channel, the SNR must be at least 13.5dB. The
conventional TNC would require a SNR of 13.5 - 5.5 = 8.0dB in a 500-Hz
bandwidth to achieve this BER; however, the DSP modem would need only a
3.5dB SNR in the same bandwidth to achieve the same BER. This is about
the limit of detectability for a modern communications receiver. In
other words, if the operator can find the signal, it will probably yield
good copy.

In the case of RTTY synchronous mode and assuming the character
synchronization is flawless, the DSP modem operates as a gated receiver.
In this mode, the contribution to the error budget due to slips is
avoided. In the interests of minimizing garble, the RTTY decoder design
is such that errors in the start and stop bits result in an erasure;
therefore,

                  WER = (1 - BER)^2 (1 - (1 - BER)^5),

which is closely approximated by WER = BER / 5 in the probability range
of interest. At the equivalent BER and a noncoherent FSK channel, the
DSP modem requires a SNR of 13.1dB, which is only a marginal improvement
over the asynchronous case. However, at the same SNR as the asynchronous
case, the synchronous decoder has a WER (14 - 5) / 14 = 64 percent less
than the asynchronous mode.

In the case of SITOR, a crude approximation to the coding gain of the
matched filter DSP modem can be gained from the following. An
approximation to the symbol error probability of a N-symbol alphabet
depends on the distance in the Euclidian space of N vertices, where the
distance between the vertices is d. The CCIR codeword has 35 symbols of
seven bits and has minimum distance two. The codeword is actually
transmitted twice, so the resulting 14-bit code has distance four. This
is equivalent to increasing the distance between the symbols by a factor
of sqrt(4) = 2.

The Baudot code has 32 symbols of seven bits, including all five-bit
code combinations, and thus has minimum distance one. As shown above,
the difference in SNR between RTTY synchronous and asynchronous modes is
small and can be neglected in view of the other approximations made
here. Therefore, both the seven-bit 50-baud Baudot code and the 14-bit
100-baud CCIR code have the same SNR at the output of the filter, since
both have the same integration time. The performance of the 14-bit CCIR
code over the seven-bit Baudot code is equivalent to increasing the SNR
by a factor of two; that is, 3dB. The crude assumptions made here make a
figure this large quit suspect; however, the main reason for the SITOR
approach is to reduce the WER. The degree to which the matched filter
reduces the WER remains to be properly analyzed and experimentally
verified.

Command Interpretation

Modem commands consists of a single letter followed by a modifier
consisting of a digit or plus sign "+" of minus sign "-". Commands take
place immediately; there is no line-end character or provision for
backspace or line-delete functions. Command characters are echoed as
received with a line-feed (LF) character echoed following a received
carriage-return (CR) character. The command interpreter is driven by a
hierarchical set of tables, together with short code sequences which
implement the various functions. The interpreter also performs
transmit/receive functions and translates received CR characters
received from the terminal program to the transmitted sequence CR-LF
when translated to Baudot.

All commands consist of single characters in either upper or lower case,
some with digit or +- modifiers. The defaults are presently set at 600-
Hz shift (m2), 75 baud (b2), 30dB limiter gain (l5), autostart gate off
(a0), sync enable off (s), display AFSK generator (d0), analog loopback
echo (e1), 850-Hz output shift (o). Some commands may affect the
settings for others; in particular, the m{1-8} command resets the c{0-
2}, e{1-3}, i, o{0-2}, p{1-2}, q, s, and u commands to their defaults.
This is probably more a bug than a feature.

Command   Default   Function
--------------------------------------
a{0-1}    a0        select autostart mode
                    0 disable autostart
                    1 enable autostart

a{+-}     midrange  adjust autostart gate threshold

b{1-6}    b2        select baud rate
                    1 100
                    2 75
                    3 50
                    4 45.45
                    5 25
                    6 10

b{+-}     midrange  adjust baud interval up/down 1 us

c{0-2}    c0        select channels
                    0 mark/space
                    1 mark only
                    2 space only

c{+-}     midrange  adjust carrier gate threshold

d{0-9}    d0        select display/output
                    0 AFSK generator
                    1 AIO input signal
                    2 filtered/limited input signal
                    3 mark signal
                    4 space signal
                    5 detector output
                    6 autostart signal
                    7 PLL phase signal
                    8 noise signal
                    9 carrier signal

e{1-3}    e1        select analog/digital loopback echo
                    1 analog loopback echo
                    2 digital loopback echo
                    3 full duplex

g{+-}     midrange  adjust filter gain

g{0-7}    g2        select analog gain
                    0 unity gain
                    1 6dB
                    2 12dB
                    3 18dB
                    4 24dB
                    5 30dB
                    5 36dB
                    7 comparator

i         normal    select upright/inverted shift (toggle)

l{0-5}    l5        select limiter gain
                    0 0dB
                    1 6dB
                    2 12dB
                    3 18dB
                    4 24dB
                    5 30dB

m{1-8}    m2        select mode, filter and shift
                    1 IIR filter, 850-Hz shift
                    2 IIR filter, 600-Hz shift
                    3 IIR filter, 400-Hz shift
                    4 IIR filter, 170-Hz shift
                    5 MF filter, 850-Hz shift
                    6 MF filter, 600-Hz shift
                    7 MF filter, 400-Hz shift
                    8 MF filter, 170-Hz shift

m{+-}     midrange  adjust space frequency up/down 10 Hz

o{0-2}    c0        select output shift
                    0 follow input shift (170 Hz narrow, 850 Hz wide)
                    1 170 Hz shift
                    2 850 Hz shift

p{1-2}    p1        select radio port
                    1 select radio port 1
                    2 select radio port 2

r                   master reset

s         off       enable/disable sync mode (toggle)

t{+-}               adjust radio frequency up/down one step

u{0-3}    off       select unshift-on-space
                    0 disable transmit and receive
                    1 enable receive
                    2 enable transmit
                    3 enable receive and transmit

v{0-1}    v0        enable/disable erasures
                    0 enable erasures
                    1 disable erasures

v{+-}               adjust erasure threshold

x         receive   transmit

y                   select CCIR mode

Note: For those commands with numeric or +- suffixes, the suffixes can
be used repeatedly for the same function. The function is redetermined
at the next command letter.

LED Indicators

LED 1 spike limiter
This LED indicates that the signal input is above the clipper threshold.
Under ordinary conditions, it should flash occasionally, but not be on
all the time.

LED 2 program running

The brightness of this LED represents the fraction of CPU cycles
available for other than signal processing. It flashes at a 2-Hz rate to
indicate an error (output buffer overflow) condition.

LED 3 carrier gate indicator

This LED on when the carrier gate is unblocked, which indicates a valid
carrier signal is being received.

LED 4 autostart gate indicator

This LED indicates the status of the character decoders. In SITOR mode
and RTTY asynchronous mode, it flashes with received characters when
unblocked by the erasure gate. In RTTY synchronous mode, it is on
continuously, but blinks with received characters when blocked by the
erasure gate. If the a1 command has been given, it also flashes with
received characters as long as the autostart gate is unblocked. If no
input data have occurred in the last 30 s or so, it will flash at a 1-Hz
rate.

LED 5 mark channel output

This LED is on when the carrier gate is unblocked and the mark channel
signal is above the carrier threshold.

LED 6 space channel output

This LED is on when the carrier gate is unblocked and the space channel
signal is above the carrier threshold.

LED 7 output space indicator

This LED is on when the encoder output is at space. It flashes at a 2-Hz
rate when the CTS signal at the UART connector is down, indicating the
output buffer is nearly full and the terminal program should cease
sending data.

LED 8 power indicator

This LED should always be on.

Scope Signals

In transmit mode, the AIO output is always connected to the AFSK
generator. In receive mode, the AIO output can be connected to a DC-
coupled scope to view various internal signals of interest, including
the AFSK generator. The d command can be used to switch among the
signals listed above. Even when a scope is not available, a speaker can
be used as a fairly accurate tuning indicator and operating aid. The d1
monitor point is the AIO input signal supplied from the receiver. The
signal amplitude should be adjusted so that LED 1 flickers occasionally,
but is not on all the time. If the amplitude is too high, the signals
will be distorted, which is readily apparent to the ear. The d2 monitor
point is the input signal after the FIR filter and limiter. If the
limiter gain is reduced to unity (l0 command), the signal can be
centered in the filter passband by ear and checked with LEDs 3 and 4.
The d5 monitor point can be used as an aural activity monitor. When no
channel activity is present, the speaker will be silent. If a carrier is
present and characters are being received, the sounds produced mimic a
clunky old Model 12. That wasn't intentional, but it is satisfying.

Bugs

The transmit mode needs a watchdog timer.

An autobaud function should be added to the UART code to handle terminal
programs operating at other than 19,200 baud.

The transmitter needs a right margin check and auto-CR/LF, especially
when using analog loopback echo.

Automatic speed select and upright/invert detect function could be
relatively easy to implement. Automatic normal/wideshift selection and
AFC would also be a valuable features, but harder to implement.

An automatic crossband repeater function would be fun. The modem could
listen on each port alternatively looking for an active autostart gate.
When heard the modem would key up the alternate transmitter.

Last updated 5 July 1995

David L. Mills, W3HCF
Electrical Engineering Department
University of Delaware
Newark, DE 19716
302 831 8247 office, 302 831 9211 home
mills@udel.edu
