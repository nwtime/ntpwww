#! /bin/csh
#
# test different hz values
#
kern -s 10000 -p 1000 -D 8 -t 4 -z 1024       # digital alpha
