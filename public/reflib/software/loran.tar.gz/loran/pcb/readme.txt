              Computer Controlled LORAN-C Timing Receiver

Pcb Directory

This directory includes seven files comprising the printed-circuit
artwork, drill, soldermask and silkscreen drawings suitable for
replication. All except this file are in PostScript format. These files
were produced using the Schema PCB printed-circuit board layout program.

        adt0127.lpr     assembly drawing
        art01.lpr       artwork - side 1
        art02.lpr       artwork - side 2
        dd0124.lpr      drill drawing
        lr.err          summary of errors and corrections to the pcb
        readme.txt      this file
        sm0228.lpr      soldermask - side 2
        sst0126.lpr     silkscreen - side 1

Note that there are a few errors in the current pcb artwork. These must
be fixed by cutting traces and installing jumpers. A summary of these
corrections is in the lr.err file.
