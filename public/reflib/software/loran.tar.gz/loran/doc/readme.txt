              Computer Controlled LORAN-C Timing Receiver

Doc Directory

This directory includes five files comprising the technical report

Mills, D.L. A computer-controlled LORAN-C receiver for precision
timekeeping. Electrical Engineering Department Report 92-3-1, University
of Delaware, March 1992, 63 pp.

All except this file are in PostScript format. These files were produced
using the Ventura Publisher publishing program.

        lorana.ps       header and table of contents
        loranb.ps       main body of text
        loranc.ps       appendix a (host computer interface)
        lorand.ps       appendix b (program listing)
        lorane.ps       appendix c (schematic drawings)
        readme.txt      this file

Note that the latest hardware and software designs documented in these
directories obsoletes the appendices of this report.
