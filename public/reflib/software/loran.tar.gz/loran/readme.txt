              Computer Controlled LORAN-C Timing Receiver

                             David L. Mills
                   Electrical Engineering Department
                         University of Delaware
                            Newark, DE 19716
                             mills@udel.edu

1. Introduction

This directory and dependent subdirectories contain the hardware and
software documentation for a precision time and frequency receiver
synchronized to stations of the LORAN-C radionavigation system. These
stations operate on an assigned radio frequency of 100 kHz and can be
received over the continental US, adjacent coastal areas and significant
areas elsewhere in the world [FRA83]. The receiver includes an IBM PC-
compatible printed-circuit (PC) card with an outboard crystal oscillator
and breakout box. With an oven-stabilized quartz crystal oscillator of
good short term stability, it provides 5-MHz and 1-pps signals for
external use with a timing accuracy better than 500 ns and a frequency
stability better than 1e-9 with respect to Universal Coordinated Time
UTC(LORAN).

The receiver is intended to be used by computer time servers operating
in very high speed networks and synchronizing operations with the
Network Time Protocol [MIL91] or equivalent. (Citations in brackets "[]"
are at the end of this document.) The receiver documented herein is of
second-generation vintage. The original prototype version was described
in a technical report included in this distribution [MIL92]. The second-
generation version includes a new hardware implementation with several
circuit refinements and major improvements in the control program.
Eventually, a third-generation version may be developed for use with
popular RISC workstations.

It is not the intent of the documentation included in this distribution
to serve as a specification for replication, although this should not be
hard for those with an electrical engineering and communications
background, but rather as an demonstration example and design exercise
using relatively inexpensive technology for precision time and frequency
transfer. The receiver can be replicated for a few hundred dollars, much
less than typical timing receivers with comparable specifications, which
cost in the $20,000 range. This is a work in progress and future
improvements in accuracy, stability and usability are expected. The
remainder of this document presents an overview of the current design
and possible future enhancements.

2. Technical Summary

The analog radio and integrated digital controller are contained on an
8" PC card that plugs directly into the IBM PC bus. The radio receives
LORAN-C signals consisting of eight-pulse, biphase-modulated pulse
groups transmitted at a 1-kHz rate [CG81]. Each of these pulse groups is
repeated at an interval characteristic of the particular LORAN-C chain,
which consists of a master station and up to four slave stations. The
radio includes a gated, synchronous detector driven by a quadrature-
phase clock, two integrators with programmable gain and a peak-reading,
signal-level detector.

The base directory contains the C-language software program which
controls the receiver. It processes the received signals using a
multiple-channel analog/digital converter and multiplexor and generates
the digital timing and analog control signals using an AMD 9513A System
Timing Controller (STC) chip, two digital/analog converters and
miscellaneous logic components. The radio provides three analog signals,
one for the in-phase integrator, another for the quadrature-phase
integrator and a third for the signal-level detector. The program
outputs the master oscillator frequency-adjustment voltage and receiver
gain-control voltage.

The receiver supports both an internal, uncompensated crystal oscillator
and an external oven-compensated crystal oscillator to derive all timing
signals used by the receiver and the program. The 5-MHz output of these
oscillators is adjustable over a small range by the program to coincide
with the LORAN-C signal as broadcast. The external oscillator should
have good intrinsic stability and setability to within less than 0.5 Hz
at 5 MHz (0.1 ppm), since it must maintain the master clock to within
100 us over the pulse-group scan interval up to several minutes.

The receiver produces a 5-MHz signal in both TTL and sinewave formats,
together with a 1-pps signal synchronized to UTC(LORAN). Measured timing
accuracy is typically better than 200 ns and short-term stability within
1e-9 relative to GPS as received. When manually adjusted using time-of-
coincidence (TOC) data published by US Naval Observatory, these signals
are suitable for use as precision time and frequency sources. The system
can be programmed to generate all sorts of other signals as well.

The program requires a data file ("loran.dat") containing the geographic
coordinates and other information about the LORAN-C chains being used.
While the data contained in the file included in the source subdirectory
were obtained from official US Coast Guard publications [CG81] and has
been updated for the WGS84 survey [USCG EECEN personal communication],
it should not be used for navigation purposes, since the stations are
periodically re-surveyed and the transmission equipment changed from
time to time. While all chains now oprating in the US and Canada are
included, other chains in Europe and Asia are not. The format of this
file is described under the subroutine heading init_loran() in the
loran.c file in the source directory.

The program was developed using Microsoft QuickC for Windows, but the
production versions are normally compiled to run under ordinary
polymorphic DOS versions. The program is adorned by copious comments
revealing design details of the algorithms, parameter-tuning procedures
and results of simulation.

The subdirectories include the following:

        source  source and header files in C

        schema  schematics and parts lists for the hardware, including
                the PC card and outboard oscillator/breakout box

        pcb     construction information, including two-side, plated-
                through-holes circuit board, artwork and drill templates

        doc     documentation, including technical reports and
                preliminary performance measurements

These files are all in DOS format and should be piped through dos2unix
to comfort Unix systems. Readme.txt files in each subdirectory give more
details about the files contained therein.

3. Future Plans for the LORAN-C Receiver Project

At the present state of development the original design goals have
largely been met with a few exceptions. However, several ideas have
emerged from the experience which have yet to be explored. These issues
are summarized in following sections, first hardware issues and then
software issues, but in no particular order. In the following the
reference "UDel receiver" refers to the device described in this
document, while reference to "Austron receiver" refers to the Model
2000C LORAN-C Timing Receiver manufactured by Austron, Inc., of Austin,
TX. The latter receiver, first manufactured over 20 years ago, is still
in use at LORAN-C stations as the primary monitoring receiver.

3.1. Hardware Issues

A thorough set of performance measurements should be collected for the
receiver, including sensitivity, bandwidth, gain and oscillator
characterisitics. The frequency stability of the oscillator (about 1e-9
peak) may be suspect due to a ground loop that needs to be repaired. The
VCO sensitivity should be reduced by at least a factor of two to reduce
the quantization error to 1e-10.

The present hardware and software design includes provisions for a peak-
reading signal detector to aid in establishing the receiver gain prior
to pulse-group search. The present design is a crock. It uses a pair of
LM324 operational amplifiers and silicon diodes in a "superdiode"
configuration. It does not operate well at 100 kHz and a maximum signal
of about 800-mv p-p. It should be redesigned using more ambitious
circuitry. The present software reads the signal, but does nothing with
it. In addition, some sort of mapping needs to be developed for the dac-
gain transfer characteristic in order to linearize the amplitude-control
feedback loop. The present dynamics of this loop are at best fanciful.

The internal oscillator has no particularly cherishable characteristics
and is primarily intended for test and alignment. It needs a voltage
attenuator between the dac output and vco input in order to provide the
fine tuning needed for this application. It also may need a manual
coarse adjustment in the form of a potentiometer; however, it may not be
stable enough for reliable synchronization. However, it may be possible
to avoid the use of an external oscillator if a sufficiently stable
replacement part is available.

The 25-pin cable between the PC card and oscillator/breakout box is
shielded, but the individual wires are not separately shielded. There is
a moderate degree of crosstalk in this cable; in particular, the
detector signal intended for oscilloscope display is quite noisy and
unsuitable for the intended use. This could easily be fixed by including
low impedance drivers on the PC board and by redriving the signals in
the breakout box. For the ultmate accuracy, the 1-pps signal produced by
the 9513 should probably be driven through a 50-ohm cable between the PC
card and breakout box.

3.2. Software Issues

The receiver presently uses a 10-us strobe to find the reference cycle
phase and amplitude. This provides the best signal/noise ratio, but may
not have the best accuracy. For instance, the Austron receiver uses a 5-
us strobe to resolve phase and a 1-us strobe to resolve amplitude. In
addition, the Austron receiver uses just the positive-going zero
crossing following the third carrier cycle, as required by the LORAN-C
signal specification [CG81], while the UDel receiver averages this zero-
crossing and the negative-going one just ahead of it. Also, the Austron
receiver can track the amplitude of either the negative cycle just ahead
or the positive cycle just behind the reference zaro crossing. However,
so far as is evident from an analysis of the circuit schematics, the
amplitude strobe is used only to drive a low-signal alarm and a pen
recorder for monitoring and quality assurance.

It is easy to make the strobe more narrow than 10 us simply by changing
the width of the strobe defined by the stb counter. This probably should
not be done until the time constant has ramped up to a substantial
fraction of its maximum value, since the signal/noise ratio will suffer.
Since a reliable alarm signal can be provided using a 5-us strobe and a
pen recorder is not necessary with a computer-controlled timing
receiver, a single 5-us strobe for both amplitude and phase should be
sufficient.

The UDel receiver requires that the receiver position be provided within
approximately one degree of latitude and longitude, which corresponds to
a position uncertainty of about 67 km or about 400 us. However, the
receiver calculates its actual position as part of normal operation. The
reason it can't calculate its position beforehand is the absence of
hyperbolic-coordinate or rho-rho navigation routines. Ideally, these
routines should be provided; however, it is probably sufficient to allow
the receiver to fine-tune its postion using one of several gradient-
descent algorithms to minimize the residual errors by incrementally
adjusting the receiver position.

While the LORAN-C pulse-coding scheme does provide about 12 dB coding
gain, the particular Golay codes used invite a hazard if synchronizing
to a distant master station when a slave station is nearby. During the
pulse-group search mode the top 20 pulse-group signal levels are ranked
separately for master and slave stations. In many cases the master
station signal is so strong relative to the slave station signals that
it is ranked first and the receiver successfully synchronizes to it.
However, when a strong slave signal is present, the master may not be
first in the ranking and phantom masters produced by the slave codes may
be ahead of it. A small amount of additional software is necessary to
deal with this problem. This software would evaluate each station
starting from the strongest, toss out the outlyers and stop at the first
master found. This software was once part of the system, but was
discarded due to misguided perceptions.

The current program has an experimental Least-Mean-Squares (LMS)
algorithm intended to suppress the effects of co-channel continuous-wave
signals. However, no interference of this type other than a the expected
low-level carrier signal at 100-kHz due to the LORAN-C pulse-code
imbalance has been a significant problem. In our area only the US Navy
transmitters at Annapolis, MD, on 134.8 kHz (encrypted radioteletype)
and occasionally 88.0 kHz (CW radiotelegraph) have been apparent.
Nevertheless, an LMS filter represents an interesting approach to
solving problems of this type.

It should be possible, and not hard, to estimate the oscillator aging
characteristic and use it to reduce timing errors during intervals when
synchronization with all LORAN-C stations is lost. This could be done
simply by fitting a second-degree polynomial to the residuals produced
by the frequency estimate.

A particularly intriguing feature would be the capability to
simultaneously synchronize to multiple LORAN-C chains. There is probably
not enough integrator or program time to track all masters and slaves of
two or more chains, but it should be possible to track the master of one
chain together with a slave of another, especially if the master of one
chain is dual-rated to a slave of another, which is common practice. The
primary reason for wanting to do this is to increase the ambiguity lane
interval from one frame to multiple frames, long enough for either an
operator or coarse-synchronized clock-calendar chip to resolve the
epoch.

The UDel receiver presently spins on busy bits to control input/output
operations, which means the controlling computer must be dedicated to
the LORAN-C functions. The software should be rebuilt to use interrupts
and operate as a transient-stay-resident (TSR) program. However, it is
not at all obvious that the program can successfully cohabit with other
system and application programs which require substantial processor or
input/output involvement.

Provisions need to be incorporated in the program to write monitoring
and performance data to a disk file. While this is in principle easy,
the overrun requirements of this real-time program are strict. However,
if it is possible to predict when a substantial overrun might occur, it
is possible to anticipate the delay and schedule one or more frame
slips, during which LORAN-C samples can be suppressed without
disruption.

The same thing can be said about remote control and monitoring. It would
be useful to have a serial-port connection to the controllin computer;
however, this would have to be carefully engineered to avoid overrun.
One possibility is to have the program scan a buffer, one character at a
time for each station, and continuously cycle through data for all
stations. The net data rate would be rather small, about ten characters
per second.

The present program reads LORAN-C station data from a disk file at
initialization time, but does not access the disk after that. There is
no particular reason why these data could not be compiled in the program
and it and the program loaded in EPROM, avoiding the use of a disk
altogether. This would be convenient if this program were used in an
embedded application, .

At its present level of refinement the UDel receiver needs a 20-MHz
80386 or faster machine with an 80387 math coprocessor. There are many
places in the code, including copious calls to math-library routines,
where floating-point operations could be avoided. While there is some
use of multi-threaded routines to interleave and pipeline the processing
to minimized latency, much remains to be done in this area. The original
goal was to run the program in old, discarded hulks of IBM PC-class
machines with no coprocessor, but that dream has faded. Earlier versions
of the program have run on 80286 platforms with 80287 coprocessors; so,
if the ability to simultaneously track all stations in a chain is
perishable, the program should run as-is on an IBM AT-class machine.

4. Comparison with Austron 2000C LORAN-C Timing Reciever Specifications

It is useful to compare the UDel receiver with comparable commercially
available equipment. The Austron 2000C LORAN-C Timing Receiver is a 20-
year old design intended as a monitor receiver for use by the LORAN-C
system itself and thus has demanding specifications. While this
particular receiver is manually controlled and capable of tracking only
one station at a time, recent designs are completely automatic like the
UDel receiver. Nevertheless, its specifications relative to accuracy and
sensitivity are typical of modern precision timing receivers. Following
is a summary of issues involved in comparing the specifications of the
Austron receiver and those of the UDel receiver as indicated by
simulation and measurement.

Antenna Input Impedance

The Austron receiver is designed for a 50-Ohm input impedance suitable
for a loop antenna, which has substantial directional and noise-
cancelling characteristics and in most cases is suitable for tracking
only a single LORAN-C station. The UDel receiver has a somewhat higher
input impedance suitable for both loop and random-wire or whip antennas,
which allow simultaneous tracking of all stations in the chain.

Sensitivity

The Austron receiver has a rated sensitivity of 10 nVrms and an offset
voltage less than 1 nVrms, both referred to a 50-Ohm input. The UDel
receiver has a measured system gain of about 105 dB and processing gain
of 12 dB. The noise floor is about 450 nV due mostly to quantizing
noise. From simulation the minimum phase-tracking signal at the detector
of roughly -30 dB below the (Gaussian) noise floor, giving an apparent
sensitivity of about 14 nV at the reference cycle, which is comparable
to the Austron receiver. However, in practical cases both receivers have
more than enough sensitivity for use throughout the coverage area of
typical LORAN-C chains.
Gain

The Austron receiver includes a calibrated attenuator which provides
gain adjustment from 0 to 99 dB in steps of 1 dB. Since this is a manual
adjustment, it is suitable for use with only a single station. The Udel
receiver provides gated, automatic gain control over substantially the
same range. The control operates on the reference cycle to maintain a
constant amplitude within approximately 1 dB for up to five stations.

Phase Detector Dynamic Range

The Austron receiver dynamic range is rated at 50 dB, normal tracking
range to saturation level. Presumably, this is measured by first
tracking a normal signal at the maximum sensitivity of 1 nVrms, then
increasing the signal level until the accuracy specifications are no
longer met. In the UDel receiver the agc normally operates to maintain a
constant reference-cycle amplitude over at least a 50 dB range, so it is
not clear how to evaluate its performance. Perhaps a more interesting
comparison is tracking a signal at maximum sensitivity with a second
LORAN-C signal of another gri, but much stronger amplitude. This has not
been measured with either receiver.

Bandwidth

The Austron receiver provides three bandwidths: 5, 20 and 50 kHz. The
first is used only during initial acquisition and alignment, while the
other two are switch-selectable by the operater to match prevaling
propagation and siting conditions. The UDel receiver has a fixed
bandwidth of 20 kHz.

Phase Strobe Detector

The Austron receiver uses a sampling, first-order, phase-error loop with
manually adjusted time constant to control the receiver timing. This
receiver normally operates in conjunction with a cesium oscillator which
operates at a stable, constant frequency. The UDel receiver uses an
adaptive-parameter, first-order, type-II phase-lock loop which controls
both the phase and frequency errors with respect to an onboard voltage-
controlled oscillator. It is not clear how to compare these
specifications

Group Repetition Interval Synthesizer

The Austron receiver uses a manually adjustable pulse-code synthesizer
which operates at a single LORAN-C period from 10,000 to 109,000 us in
steps of 100 us. In the UDel receiver these periods, as well as other
characteristics of the synthesized signals, are programmable in 10-us
steps. Since these are programmable, it is in principle possible to
syncrhonize to multiple chains operating at different gri's.

The Austron receiver includes the capability to alter the pulse-code
schedule to eliminate certain pulses. There are two "balanced" modes in
addition to the normal "unbalanced" mode. The pulse codes for these
modes in the case of the master codes are as follows (+ = positive
phase, - = negative phase, x = pulse absent):

                        gri A                   gri B

        normal          + - - + + + + +         + + - - + - + -
        frame balance   x - x + x + x +         x + x - x - x -
        group balance   + - - + x x x x         + + - - + - + -

The intent of these modes is to provide further suppression of the
carrier signal, which is normally only 16 dB down from the pulse peak
due to the 10/6 imbalance in the ratio of positive to negative pulses.
Since the Austron receivers are sometimes located at transmitting sites
in strong rf fields, the balanced modes would be useful in reducing
incidental local carrier signal while listening for other distant
stations. As the UDel receiver is not intended for use at a LORAN-C
transmitter site, provision of these modes is probably not useful.

Blink Alarms

The Austron receiver has been modified by the US Coast Guard to provide
an alarm signal when the monitored station turns certain pulses off and
on in a controlled manner to indicate the station is out of tolerance or
otherwise unsuitable for navigation. There are also provisions for an
interstation communication system by modulating certain pulses of the
pulse group. These provisions have not been included in the UDel
receiver.

5. References

[CG81] Department of Transportation U.S. Coast Guard. Specifications of
the Transmitted LORAN-C Signal. COMDTINST M16562.4, July 1981. This
document may be obtained from COMMANDANT (G-NRN-3/TP14) U.S. Coast
Guard, Washington, DC 20593.

[FRA83] Frank, R.L. Current developments in LORAN-C. Proc. IEEE 71, 10
(October 1983), 1127-1139.

[MIL91] Mills, D.L. Internet time synchronization: the Network Time
Protocol. IEEE Trans. Communications 39, 10 (October 1991), 1482-1493.

[MIL92] Mills, D.L. A computer-controlled LORAN-C receiver for precision
timekeeping. Electrical Engineering Department Report 92-3-1, University
of Delaware, March 1992, 63 pp.
