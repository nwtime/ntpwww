              Computer Controlled LORAN-C Timing Receiver

Source Directory

This directory includes five files comprising the control program and
one data file. The program was developed using Microsoft QuickC for
Windows, but the production versions are normally compiled to run under
ordinary polymorphic DOS versions. The program is adorned by copious
comments revealing design details of the algorithms, parameter-tuning
procedures and results of simulation. The data file includes geographic
coordinates and emission delays for all US and Canadian LORAN-C chains.

        gri.c           signal processing subroutines
        loran.c         main program
        loran.dat       data file containing LORAN-C station
                        coordinates and emission delays
        loran.h         header file used by all programs
        readme.txt      this file
        subs.c          input/output and utility subroutines
        tables.c        initialization tables

The program takes three optional parameters in the command line. The
first is the group-repetition interval (GRI), which defaults to 9960 for
the US North East chain, while the second and third are the initial
values for the agc dac and vco dac, respectively. The defaults for these
two parameters are in the header file. The actual setting of the agc
parameter depends on the antenna, siting and ambient electrical noise in
the vicinity of the receiver and normally requires an oscilloscope;
however, once set it normally does not need to be changed.

The program can be used both for simulation and to control the actual
receiver, but not at the same time. There is a compilation parameter
DEBUG in the header file that determines which mode. If it is defined,
the program operates as a simulator; if not, it operates the real thing.

There are a number of tuning parameters which have been optimized by
simulation and experimentally tweaked in actual operation. Each of these
is described in detail, along with comments on how the selected values
were determined, in the header file.
