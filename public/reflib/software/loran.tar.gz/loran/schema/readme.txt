              Computer Controlled LORAN-C Timing Receiver

Schema Directory

This directory includes 13 files comprising the circuit diagrams and
timing diagrams for the PC interface and oscillator/breakout box. All
except this file, those with .lst and those with .jed extension are in
PostScript format; the exceptions are in ASCII format. All except the
files with .jed extension were produced using the Schema III schematic-
capture program; the .jed files were produced using the PALASM
programmed-array logic design program. Note that U12 and U14 have not
yet been converted from PAL20L8 to PAL22V10.

        readme.txt      this file
        lr.s01          system diagram
        lr.so2          receiver circuits
        lr.s03          preamplifier circuits
        lr.s04          receiver control circuits (1 of 2)
        lr.s05          receiver control circuits (2 of 2)
        lr.s06          receiver timing diagrams
        lr.lst          PC board parts list, wiring lists, etc.
                        lists, etc.
        osc.s01         oscillator/breakout box
        osc.lst         oscillator/breakout box parts list, wiring
        parts.txt       parts list (editd)
        u12.jed         JEDEC file for PAL U12 PAL20L8
        u14.jed         JEDEC file for PAL U14 PAL20L8
        u5.jed          JEDEC file for PAL U5 PAL22V10
