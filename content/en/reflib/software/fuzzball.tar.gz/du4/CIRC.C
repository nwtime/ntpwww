#include	<std.h>
#include	<rt11.h>

#define DISXMAX 640
#define DISYMAX 512
#define DIS2YMAX 256

TEXT	linbuf[80] = "                           ";
BYTES	*creg	=	0774764;
BYTES	*datareg  =     0775000;
BYTES	mask[] = {01,010,0100,01000,010000};

/************************************************/
main()
{
int	ox,oy,r;
TEXT	*s;

FOREVER {
	s = getstr("type x y r",linbuf);
	s = s+btoi(s,10,&ox,10);
	s = s+btoi(s,10,&oy,10);
	s = s+btoi(s,10,&r,10);
	circ(ox,oy,r);
	}
}

/*********************************************/
circ(ox,oy,r)
int 	ox,oy,r;

{
FAST	int	x,y,ysave;
long	y2,rx2,y2temp;

y=r;
y2 = (rx2 = (long) r*r);
x = 0;

for ( ; x <= y; x +=1 ) {
	ysave=y;

	for ( ; y2 > rx2; y -= 1 ) y2 -= (long)  (y+y-1);

	y2temp =(long) ( y2 +y +y +1);
	if ( (rx2-y2) > (y2temp -rx2) ) {
		y2=y2temp;
		y += 1;
	}

 /*	putdec(x,"  ");
	putdec(y,"\n");
*/
	point(ox+x,oy+y);
	point(ox+x,oy-y);
	point(ox-x,oy+y);
	point(ox-x,oy-y);

	point(ox+y,oy+x);
	point(ox+y,oy-x);
	point(ox-y,oy+x);
	point(ox-y,oy-x);

	if(ysave != y) {
		point(ox+x,oy+ysave);
		point(ox+x,oy-ysave);
		point(ox-x,oy+ysave);
		point(ox-x,oy-ysave);
	
		point(ox+ysave,oy+x);
		point(ox+ysave,oy-x);
		point(ox-ysave,oy+x);
		point(ox-ysave,oy-x);
		}

	rx2 -= (long) (x+x+1);
	}
}

/********************************************************/
point(x,y)
FAST	int	x,y;

{
if ( (x >= 0) &&(y >= 0) && (x < DISXMAX) && (y < DISYMAX) ) {
	*creg = 060;
	if (y >= DIS2YMAX) *creg |=0200;
	*creg |= (y << 8);
	*(datareg +  (x/5) ) |= mask[x%5];
	}
}

/*********************************************************/
TEXT	*getstr(prompt,buff)
TEXT	*prompt;
TEXT	buff[];

{
putstr(STDOUT,prompt,NULL);
buff[getlin(buff,79) - 1] = NULL;
return(buff);

}	/* of getstr */


/*********************************************************/
putdec(n,s)
TEXT	*s;
int	n;
{
linbuf[itob(linbuf,n,-10)]=NULL;
putstr(STDOUT,linbuf,s,NULL);
}
                                                      