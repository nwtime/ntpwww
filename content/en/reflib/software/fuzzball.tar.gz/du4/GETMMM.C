/*********************************************************/
#include	<std.h>
#include	<rt11.h>
#include	<mmmhdr.h>


/*********************************************************/
/****** functions from gmmmel */
int	getitem();
int	gindex(),gproplist(),glist(),intprnt();
long	gint(),gtext(),gbitstr();
TEXTPTR	gname();

/*********************************************************/
/****** functions from supprt */
int initnode(),link();

/*********************************************************/
/***** entry points */


/*********************************************************/
TEXT	junk[];
TEXT	linbuf[];

FILE	fd;
int	lcurx,lcury;
int	tabsiz;
int	dumpflag;
TEXT	filenam[];
TEXT	err1[] = "unknown proplist elem ??";

TEXT	*algnam[] ;
int	maxalg;
TREEPTR mtop,present;


/*********************************************************/
/*********************************************************/
dumper()

{
long	octcnt;
int	item;

dumpflag = 1;
intprnt();
for ( ;  ; ) {
	switch(item = getitem(fd)){
		case 0: break;
		case 1: break;
		case 2: break;
		case 3: {
			gindex(fd);
			break;
			}
		case 4: {
			gint(fd);
			break;
			}
		case 5: break;
		case 6: {
			gbitstr(fd);
			break;
			}
		case 7: {
			gname(fd,linbuf);
			break;
			}
		case 8: {
			gtext(fd,&octcnt);
			break;
			}
		case 9: {
			glist(fd,&octcnt);
			break;
			}
		case 10: {
			gproplist(fd,&octcnt);
			break;
			}
		case 11: break;
		default: putstr(STDOUT,err1,NULL);
		}
	if( (item == TELIST) && (tabsiz == -2) ) break;
	}
putstr(STDOUT,"\n",NULL);
}

/*********************************************************/
readmmm(node)
TREEPTR node;
{
static	int	maxitem = 6;
static	TEXT	*itemtab[]
	{"DATE","FROM","TO","CC","SUBJECT","BODY"};
static	PFI	func[] = 
	{&gdate,&gfrom,&gto,&gcc,&gsubject,&gbody };

intprnt();
getitem(fd);
callfunc(node,itemtab,maxitem,func);
putstr(STDOUT,"\n",NULL);
}

/*********************************************************/
gdate(node)
TREEPTR node;
{
getitem(fd);
gname(fd,linbuf);
putstr(STDOUT,"DATE: ",linbuf,"\n",NULL);
}

/*********************************************************/
gfrom(node)
TREEPTR node;
{
putstr(STDOUT,"FROM: ","\n",NULL);
gmbs(node);
}

/*********************************************************/
gto(node)
TREEPTR node;
{
putstr(STDOUT,"TO: ","\n",NULL);
gmbs(node);
}
/*********************************************************/
gcc(node)
TREEPTR node;
{
putstr(STDOUT,"CC: ","\n",NULL);
gmbs(node);
}

/*********************************************************/
gmbs(node)
TREEPTR node;
{
static	int	maxitem = 3;
static	TEXT	*itemtab[]
	{"HOST","USER","PERSON"};
static	PFI	func[] = 
	{&ghost,&guser,&gperson};
long octcnt;

getitem(fd);
glist(fd,&octcnt);
while (getitem(fd) == TPLIST ) 
	callfunc(node,itemtab,maxitem,func);

}

/*********************************************************/
ghost(node)
TREEPTR node;
{
putstr(STDOUT,"    HOST: ",NULL);
gmbitem(node);
}

/*********************************************************/
guser(node)
TREEPTR node;
{
putstr(STDOUT,"    USER: ",NULL);
gmbitem(node);
}
/*********************************************************/
gperson(node)
TREEPTR node;
{
putstr(STDOUT,"    PERSON: ",NULL);
gmbitem(node);
}

/*********************************************************/
gmbitem(node)
TREEPTR node;
{
getitem(fd);
gname(fd,linbuf);
putstr(STDOUT,linbuf,"\n",NULL);
}

/*********************************************************/
gsubject(node)
TREEPTR node;
{
long	sav;

putstr(STDOUT,"SUBJECT: ","\n",NULL);
getitem(fd);
gtext(fd,&sav);
}



/*********************************************************/
gbody(node)
TREEPTR node;

{
static	int	maxitem = 1;
static	TEXT	*itemtab[]
	{"MULTIMEDIA"};
static	PFI	func[] = 
	{&gmulmedia};

getitem(fd);
callfunc(node,itemtab,maxitem,func);
}

/*********************************************************/
gmulmedia(node)
TREEPTR node;
{
static	int	maxitem = 2;
static	TEXT	*itemtab[]
	{"TEXT","IMAGE"};
static	PFI	func[] = 
	{&gtexdoc,&gimage };

getitem(fd);
callfunc(node,itemtab,maxitem,func);
}


/*********************************************************/
gtexdoc(node)
TREEPTR node;

{
TREEPTR newnode;
static	int	maxitem = 3;
static	TEXT	*itemtab[]
	{"PROTOCOL","VERSION","DATA"};
static	PFI	func[] = 
	{&gtxprot,&gtxversion,&gtxdata };

if((newnode=nalloc(sizeof(*node),node) )==NULL){
	putstr(STDERR,"out of storage");
	return;
	}

initnode(newnode);
newnode->alg = ALGTEXT;
cpystr(newnode->filnam,filenam,NULL);
link(node,newnode);

getitem(fd);
callfunc(newnode,itemtab,maxitem,func);
}

/*********************************************************/
gtxversion(node)
TREEPTR node;
{
getitem(fd);
gindex(fd);
}

/*********************************************************/
gtxprot(node)
TREEPTR node;
{
getitem(fd);
gname(fd,linbuf);
}

/*********************************************************/
gtxdata(node)
TREEPTR node;
{
TREEPTR newnode;
long	octcnt;

getitem(fd);
glist(fd,&octcnt);
while ( getitem(fd) == TTEXT){
	if((newnode=nalloc(sizeof(*node),node) )==NULL){
		putstr(STDERR,"out of storage");
		return;
		}
	initnode(newnode);
	link(node,newnode);
	cpystr(newnode->filnam,filenam,NULL);
	newnode->segxsiz = (int) gtext(fd,&newnode->filptr);
	}
}



/*********************************************************/
gimage(node)
TREEPTR node;

{
static	int	maxitem = 3;
static	TEXT	*itemtab[]
	{"PROTOCOL","VERSION","DATA"};
static	PFI	func[] = 
	{&gtxprot,&gtxversion,&gfxdata };

getitem(fd);
callfunc(node,itemtab,maxitem,func);

}

/*********************************************************/
gfxdata(parnode)
TREEPTR parnode;
{
TREEPTR snode,*node;

if( (node=getnode() ) == NULL) return;
initnode(node);
link(parnode,node);
getitem(fd);
gsegment(node);

iniptrav(node);
gdrest(snode=ptrav()) ;
if (parnode != mtop) {
	snode->scrxpos=lcurx;
	snode->scrypos=lcury;
	}
else	{
	snode->scrxpos=0;
	snode->scrypos=0;
	}
while ( snode=ptrav() ) gdrest(snode);
present=node;
 
}


/*********************************************************/
gsegment(node)
TREEPTR node;

{
static	int	maxitem = 4;
static	TEXT	*itemtab[4]
	{"ID","DESCRIPTOR","DATA","SEGLIST"};
static	PFI	func[] = 
	{&gid,&gdescriptor,&gdata,&gseglist };

callfunc(node,itemtab,maxitem,func);

}


/*********************************************************/
gid(node)
TREEPTR node;

{
static	int	maxitem = 5;
static	TEXT	*itemtab[5]
	{"IDENT","DESCRIPTION","RECORDER","ORIGIN","DATE"};
static	PFI	func[] = 
	{&gident};

getitem(fd);
callfunc(node,itemtab,maxitem,func);
}


/*********************************************************/
gident(node)
TREEPTR node;
{
getitem(fd);
node->id=gindex(fd);

}


/*********************************************************/
gdescriptor(node)
TREEPTR node;

{
static	maxitem = 8;
static	TEXT	*itemtab[8]
	{"SIZE","RESOLUTION","PALETTE","POSITION",
	  "ALGORITHM","TOLERANCE","START","MAG"};
static	PFI	func[] =
	{&gsize,&gresolution,&gpalette,&gposition,
	&galgorithm,&gtolerance,&gstart,&gmag };

getitem(fd);
callfunc(node,itemtab,maxitem,func);

}


/*********************************************************/
gsize(node)
TREEPTR node;

{
static	int	maxitem = 2;
static	TEXT	*itemtab[2]
	{"XPELS","YPELS"};
static	PFI	func[] =
	{&gxpels,&gypels};

getitem(fd);
callfunc(node,itemtab,maxitem,func);

}

/*********************************************************/
gxpels(node)
TREEPTR node;
{
getitem(fd);
node->segxsiz= (int) gint(fd);
node->xsiz=node->segxsiz;

}

/*********************************************************/
gypels(node)
TREEPTR node;

{
getitem(fd);
node->segysiz=(int) gint(fd);
node->ysiz=node->segysiz;

}

/*********************************************************/
gresolution(node)
TREEPTR node;

{
static	maxitem = 4;
static	TEXT	*itemtab[4]
	{"XPELS","XMM","YPELS","YMM"};
static	PFI	func[] =
	{&gresx,&gresxmm,&gresy,&gresymm};

getitem(fd);
callfunc(node,itemtab,maxitem,func);

}

/*********************************************************/
gresx(node)
TREEPTR node;
{
getitem(fd);
node->resx=(int) gint(fd);

}

/*********************************************************/
gresxmm(node)
TREEPTR node;
{
getitem(fd);
node->resxmm=(int) gint(fd);

}

/*********************************************************/
gresy(node)
TREEPTR node;
{

getitem(fd);
node->resy=(int) gint(fd);

}

/*********************************************************/
gresymm(node)
TREEPTR node;
{

getitem(fd);
node->resymm=(int) gint(fd);

}


/*********************************************************/
gposition(node)
TREEPTR node;

{
static	maxitem = 4;
static	TEXT	*itemtab[4]
	{"X","Y","XREL","YREL"};
static	PFI	func[] =
	{&gxpos,&gypos};

getitem(fd);
callfunc(node,itemtab,maxitem,func);

}

/*********************************************************/
gxpos(node)
TREEPTR node;

{

getitem(fd);
node->segxpos=(int) gint(fd);

}

/*********************************************************/
gypos(node)
TREEPTR node;

{

getitem(fd);
node->segypos=(int) gint(fd);

}

/*********************************************************/
gpalette(node)
TREEPTR node;

{
}

/*********************************************************/
galgorithm(node)
TREEPTR node;

{
static	maxitem = 1;
static	TEXT	*itemtab[1]
	{"NAME"};
static	PFI	func[] =
	{&galgnam};

getitem(fd);
callfunc(node,itemtab,maxitem,func);

}

/*********************************************************/
galgnam(node)
TREEPTR node;

{
int	i;

getitem(fd);
gname(fd,linbuf);
for (i=0; (i<maxalg) && (!( cmpstr(linbuf,algnam[i]))) ;i++);
node->alg=i;

}

/*********************************************************/
gtolerance(node)
TREEPTR node;

{
}

/*********************************************************/
gstart(node)
TREEPTR node;

{
static	maxitem = 2;
static	TEXT	*itemtab[2]
	{"X","Y"};
static	PFI	func[] =
	{&gxstart,&gystart};

getitem(fd);
callfunc(node,itemtab,maxitem,func);

}

/*********************************************************/
gxstart(node)
TREEPTR node;

{
getitem(fd);
node->startx=gindex(fd);

}

/*********************************************************/
gystart(node)
TREEPTR node;

{

getitem(fd);
node->starty=gindex(fd);

}

/*********************************************************/
gmag(node)
TREEPTR node;

{
static	maxitem = 4;
static	TEXT	*itemtab[4]
	{"MAGX","MAGY","MAGXBAS","MAGYBAS"};
static	PFI	func[] =
	{&gmagx,&gmagy,&gmagxbas,&gmagybas};

getitem(fd);
callfunc(node,itemtab,maxitem,func);

}

/*********************************************************/
gmagx(node)
TREEPTR node;

{

getitem(fd);
node->magx=gindex(fd);

}

/*********************************************************/
gmagy(node)
TREEPTR node;

{

getitem(fd);
node->magy=gindex(fd);

}

/*********************************************************/
gmagxbas(node)
TREEPTR node;

{
getitem(fd);
node->magxbas=gindex(fd);

}

/*********************************************************/
gmagybas(node)
TREEPTR node;

{

getitem(fd);
node->magybas=gindex(fd);

}

/*********************************************************/
gdata(node)
TREEPTR node;

{
if (getitem(fd)== TNAME) {
	gname(fd,node->filnam);
	node->filptr= (long) 0;
	node->dataflag=1;
	}
else	{
	cpystr(node->filnam,filenam,NULL);
	gbitstr(fd,&node->filptr);
	node->dataflag=1;
	}

}

/*********************************************************/
gseglist(parnode)
TREEPTR parnode;
{
int	i;
long	octcnt;
TREEPTR node;

getitem(fd);
glist(fd,&octcnt);

while ( getitem(fd) != TELIST ) {
	if( (node=getnode() ) == NULL) return;
	initnode(node);
	link(parnode,node);
	gsegment(node);
	}
}


/*********************************************************/
gdrest(node)
FAST	TREEPTR node;

{
FAST	TREEPTR parnode;
int	x,xb,y,yb;

x=node->magx;
xb=node->magxbas;
y=node->magy;
yb=node->magybas;
getmag(node);
node->magx *= x;
node->magxbas *= xb;
node->magy *= y;
node->magybas *= yb;
magfactor(node);

parnode=node->upptr;
gtscrsiz(node);
if ( parnode && (parnode != mtop) ) {
	node->scrxpos=parnode->scrxpos+
	sizmap(node->segxpos,parnode->resx,parnode->resxmm,SCRXRES,SCRXMM);
	node->scrypos=parnode->scrypos+
	sizmap(node->segypos,parnode->resy,parnode->resymm,SCRYRES,SCRYMM);
	}
}


/*********************************************************/
callfunc(node,itemtab,maxitem,func)
TREEPTR node;
TEXT	*itemtab[];
int	maxitem;
PFI	func[];

{
int	i;
long	octcnt;

gproplist(fd,&octcnt);
while ( getitem(fd)==TNAME ) {
	gname(fd,linbuf);
	for (i=0; (i<maxitem) && (!( cmpstr(linbuf,itemtab[i])));i++);
	if (i < maxitem ) (*func[i])(node);
	else putstr(STDOUT,err1,NULL);
	}
}
                                                                                                                 